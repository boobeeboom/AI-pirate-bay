#!/usr/bin/env python3
"""tree.py - show operating guidance and working memory"""

import argparse
import ast
from pathlib import Path


SIZE_THRESHOLD = 4_000
TOOLS = Path(__file__).resolve().parent


def label(entry):
    name = entry.name + ("/" if entry.is_dir() else "")
    details = []
    if entry.is_file():
        size = entry.stat().st_size
        if size >= SIZE_THRESHOLD:
            details.append(f"{size / 1_000_000:.0f} MB" if size >= 1_000_000 else f"{size / 1_000:.0f} kB")
        if entry.suffix == ".py" and entry.is_relative_to(TOOLS):
            doc = ast.get_docstring(ast.parse(entry.read_text(encoding="utf-8")))
            if doc:
                summary = doc.splitlines()[0]
                if summary.startswith(entry.name):
                    name = summary
                else:
                    details.append(summary)
    return " - ".join([name, *details])


def tree(directory, prefix="  "):
    entries = sorted(
        (entry for entry in directory.iterdir() if not entry.name.startswith(".") and entry.name != "__pycache__"),
        key=lambda entry: entry.name,
    )
    for entry in entries:
        print(f"{prefix}{label(entry)}")
        if entry.is_dir() and not entry.is_symlink():
            tree(entry, prefix + "  ")


def main():
    argparse.ArgumentParser(description=__doc__).parse_args()
    repository = Path(__file__).resolve().parents[2]
    print(f"{repository.name}/")
    tree(repository)


if __name__ == "__main__":
    main()
