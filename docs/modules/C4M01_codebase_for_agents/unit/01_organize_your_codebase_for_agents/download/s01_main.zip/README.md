# Workshop Reservations

Create workshops, share their links, and reserve seats. The product vision and vocabulary are in [product.md](docs/product.md); the accepted contract is in [behavior.md](docs/behavior.md).

## Run

Use the pinned Nix environment:

```sh
nix develop -c make run
```

With Go 1.27.1 or later already installed, use `make run`. Open [localhost:8080](http://localhost:8080).

Data lives in `var/workshops.sqlite`. Restarting preserves the event history and rebuilds projections. Run one service process per database file. The product's unauthenticated access and visibility boundaries are described in [product.md](docs/product.md).

To choose a listen address or database:

```sh
go run ./cmd/workshops -addr 127.0.0.1:8081 -db var/workshops_2.sqlite
```

## Development

`make specs` runs the standalone, sequential spec runner (`go run ./cmd/specs`), printing failure details and a compact summary. `make check` runs those specs and infrastructure unit tests with the race detector, then vet and an executable build. Prefix either with `nix develop -c` when using Nix. Checks use isolated databases and need no running server.

Every spec run validates `Covers` links against the accepted requirements. `nix develop -c go run ./cmd/specs -coverage` also reports each requirement's linked scenarios and outcomes after the full run.

The application lives in `app/`, durable event types and decoding in `evt/`, the declarative specification model and verification in `spec/`, executable behavior scenarios in `specs/`, and application entry points in `cmd/workshops` and `cmd/specs`.

- [Specifications](docs/specifications.md) describes the verification boundary.
- [Working modes](docs/modes/) contains piecemeal growth and document-writing guidance.
- [Feature proposals](docs/features/) contains pending product changes.
