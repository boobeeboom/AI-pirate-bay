package specs

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/spec"
)

func workshopCatalogueSpecs() spec.Specs {
	var specs spec.Specs

	specs.Add("Visitor opens an empty catalogue", func(bld *spec.B) {
		bld.When(spec.Get("/")).
			Then("the catalogue points to creation before any workshops exist").
			Covers("W8").
			ExpectEl("#empty-workshops a", spec.With{"href": "/workshops/new"}).
			ExpectNoElement(`form[action="/workshops"]`)
	})

	specs.Add("Organizer opens workshop reservations from the catalogue", func(bld *spec.B) {
		givenWorkshopCatalogue(bld)
		october := workshopCatalogueRow("october")
		november := workshopCatalogueRow("november")

		bld.When(spec.Get("/")).
			Then("each workshop title opens its reservations without exposing another row action or reserved email").
			Covers("W8").
			ExpectEl(`a[href="/workshops/october/reservations"]`).
			ExpectElementCount(october+" a", 1).
			ExpectEl(`a[href="/workshops/november/reservations"]`).
			ExpectElementCount(november+" a", 1).
			ExpectNoText(evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"}.Email)
	})

	specs.Add("Organizer reads workshop seat counts", func(bld *spec.B) {
		givenWorkshopCatalogue(bld)

		bld.When(spec.Get("/")).
			Then("each workshop shows its reserved, total, and remaining seats").
			Covers("W8").
			ExpectVisibleText(
				workshopCatalogueRow("october"),
				"1 / 1 reserved",
				"0 remaining",
			).
			ExpectVisibleText(
				workshopCatalogueRow("november"),
				"0 / 2 reserved",
				"2 remaining",
			)
	})

	specs.Add("Organizer distinguishes full and available workshops", func(bld *spec.B) {
		givenWorkshopCatalogue(bld)

		bld.When(spec.Get("/")).
			Then("a workshop's visible availability follows its remaining seats").
			Covers("W8").
			ExpectVisibleText(workshopCatalogueRow("october"), "Full").
			ExpectVisibleText(workshopCatalogueRow("november"), "Available")
	})

	return specs
}

func givenWorkshopCatalogue(bld *spec.B) {
	bld.Given(
		evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1},
		evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"},
		evt.WorkshopCreated{WorkshopID: "november", Title: "Foundations", Capacity: 2},
	)
}

func workshopCatalogueRow(workshopID string) string {
	return `li:has(a[href="/workshops/` + workshopID + `/reservations"])`
}
