package main

import (
	"ai_code_october_specs/spec"
	"bufio"
	"fmt"
	"io"
	"regexp"
	"slices"
	"strings"
	"text/tabwriter"
)

type requirement struct {
	ID   spec.RequirementID
	Text string
}

var requirementLine = regexp.MustCompile(`^(W[0-9]+)\.\s+(.+)$`)

func readRequirements(reader io.Reader) ([]requirement, error) {
	var requirements []requirement
	seen := map[spec.RequirementID]int{}
	scanner := bufio.NewScanner(reader)
	line := 0
	for scanner.Scan() {
		line++
		match := requirementLine.FindStringSubmatch(scanner.Text())
		if match == nil {
			continue
		}
		id, err := spec.ParseRequirementID(match[1])
		if err != nil {
			return nil, fmt.Errorf("line %d: %w", line, err)
		}
		if previous, exists := seen[id]; exists {
			return nil, fmt.Errorf("line %d: duplicate requirement %s (first at line %d)", line, id, previous)
		}
		seen[id] = line
		requirements = append(requirements, requirement{ID: id, Text: match[2]})
	}
	if err := scanner.Err(); err != nil {
		return nil, err
	}
	if len(requirements) == 0 {
		return nil, fmt.Errorf("no numbered requirements found")
	}
	return requirements, nil
}

func validateRequirements(requirements []requirement, features []spec.Feature) error {
	known := make(map[spec.RequirementID]bool, len(requirements))
	for _, requirement := range requirements {
		known[requirement.ID] = true
	}
	for _, feature := range features {
		for _, scenario := range feature.Specs {
			if len(scenario.Requirements) == 0 {
				return fmt.Errorf("%s / %s: missing Covers requirements", feature.Name, scenario.Name)
			}
			seen := map[spec.RequirementID]bool{}
			for _, id := range scenario.Requirements {
				if !known[id] {
					return fmt.Errorf("%s / %s: unknown requirement %q", feature.Name, scenario.Name, id)
				}
				if seen[id] {
					return fmt.Errorf("%s / %s: duplicate requirement %s", feature.Name, scenario.Name, id)
				}
				seen[id] = true
			}
		}
	}
	return nil
}

type scenarioOutcome struct {
	Feature  string
	Scenario spec.Spec
	Failures []error
}

func printCoverage(out io.Writer, requirements []requirement, outcomes []scenarioOutcome) {
	fmt.Fprintln(out, "\nRequirement interpretations (PASS does not establish completeness):")
	writer := tabwriter.NewWriter(out, 0, 4, 2, ' ', 0)
	fmt.Fprintln(writer, "REQUIREMENT\tSTATE\tSCENARIO\tTHEN")
	for _, requirement := range requirements {
		linked := false
		for _, outcome := range outcomes {
			if !slices.Contains(outcome.Scenario.Requirements, requirement.ID) {
				continue
			}
			linked = true
			state := "PASS"
			if len(outcome.Failures) > 0 {
				state = "FAIL"
			}
			fmt.Fprintf(writer, "%s\t%s\t%s / %s\t%s\n", requirement.ID, state, outcome.Feature, outcome.Scenario.Name, outcome.Scenario.Meaning)
		}
		if !linked {
			fmt.Fprintf(writer, "%s\tNONE\t(no linked scenario)\t%s\n", requirement.ID, requirement.Text)
		}
	}
	_ = writer.Flush()
}

func describeRequirements(requirements []spec.RequirementID) string {
	ids := make([]string, len(requirements))
	for index, id := range requirements {
		ids[index] = string(id)
	}
	return strings.Join(ids, ", ")
}
