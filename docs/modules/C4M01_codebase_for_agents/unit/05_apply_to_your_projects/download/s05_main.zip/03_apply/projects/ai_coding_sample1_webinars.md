# Workshop Reservations

- Checkout: `../ai_coding_sample1_webinars`, relative to this control center's root.
- Purpose: the AI Native Code webinar sample, a workshop reservation application used to demonstrate working with coding agents.
- Entry point: `AGENTS.md` in that checkout. Use its discovery instructions to find current product requirements, operating guidance, tools, and verification commands.

## Adoption notes

No practice adoption has been performed through this center yet. Existing project guidance remains in the project.
