# Progressive disclosure for agent context

## Finding context before deciding

The question is how a fresh agent finds the context it needs before making decisions, across different agent architectures. [Anthropic's context engineering article](../cards/effective_context_engineering_for_ai_agents.md) describes progressive disclosure as successive exploration: lightweight references lead to selected material, and each retrieval informs the next. Names, folder locations, sizes, and timestamps help the agent choose where to look. This advances the question from how much context to provide to how the agent discovers what matters next.

## Connecting navigation to preserved detail

The [Unit 3 walkthrough](../cards/unit_03_walkthrough_transcript.md) gives a concrete counterpart: documents form trees both through folders and through Markdown headings, so an outline can expose the relevant section of a large document. It discusses keeping requirements, executable specifications, and code connected as those trees grow. Its Q&A also distinguishes file grouping for human convenience from the agent's ability to search for a contract clause.

Read together, the sources suggest that useful organization needs both navigational cues and routes to detailed evidence. A short entry point can help an agent select a passage without replacing the underlying material. This is a synthesis of the sources, not evidence that any particular hierarchy or outline tool reliably leads every agent to all necessary context.

## Exploration has costs

Anthropic describes slower runtime exploration and the risk of dead ends, tool misuse, or missed information. Its hybrid approach supplies some context initially and leaves further retrieval to the agent. The article also separates discovery from persistence: notes retain selected findings across context resets, while compaction risks discarding details that later matter. Progressive disclosure therefore leaves two decisions open: what must be visible before exploration starts, and what discovered information must survive afterward.

## Questions to carry forward

- What minimum initial guidance lets a fresh agent locate authoritative requirements before making a product decision?
- Which names, headings, and references help agents find necessary context, and which lead to omissions or dead ends?
- What observations would distinguish effective discovery from merely loading fewer tokens: missed constraints, retrieval time, or correctness of the resulting decision?
- How well does the same organization work across agent architectures and after a context reset?
