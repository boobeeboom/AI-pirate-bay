# Release a seat

Status: proposed — decisions pending; not implemented or covered by executable specifications.

## Intent

A participant who can no longer attend should be able to release their seat, making it available to someone else.

## Open decisions

- What should happen if the entered email has no reservation?
- What should happen when a person submits the same action twice?
- Can they reserve again afterwards?
- What should another visitor observe when a place becomes available?
- How should the catalogue and the participant's status reflect the change?
- Which outcomes need durable event evidence, and which need visible page evidence?

Resolve these questions before incorporating the feature into `behavior.md` and its executable specifications.
