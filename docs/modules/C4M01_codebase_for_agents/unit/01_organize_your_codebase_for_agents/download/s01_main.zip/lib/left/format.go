package left

import "fmt"

func formatDelta(path, expected, actual string) string {
	return fmt.Sprintf("%s: expected %s got %s", path, expected, actual)
}

func isIdentifier(value string) bool {
	if value == "" {
		return false
	}
	for i, r := range value {
		switch {
		case r == '_':
		case r >= 'a' && r <= 'z':
		case r >= 'A' && r <= 'Z':
		case i > 0 && r >= '0' && r <= '9':
		default:
			return false
		}
	}
	return true
}
