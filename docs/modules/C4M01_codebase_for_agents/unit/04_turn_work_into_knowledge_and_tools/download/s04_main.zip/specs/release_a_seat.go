package specs

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/spec"
	"net/http"
)

func releaseSeatSpecs() spec.Specs {
	var specs spec.Specs
	workshop := evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1}
	aliceReserved := evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"}
	aliceReleased := evt.SeatReleased{WorkshopID: "october", Email: "alice@example.com"}

	specs.Add("Participant checks a reserved email to release a seat", func(bld *spec.B) {
		bld.Given(workshop, aliceReserved)
		bld.When(spec.Get("/workshops/october?email=ALICE%40EXAMPLE.COM")).
			Then("a reserved participant can release the seat even when the workshop is full").
			Covers("W13", "W2", "W3").
			ExpectEl("#reservation-status", spec.With{"data-status": "reserved"}).
			ExpectEl("#release-form", spec.With{"method": "post", "action": "/workshops/october/release"}).
			ExpectEl(`#release-form input[name="email"]`, spec.With{"value": "alice@example.com"}).
			ExpectEl(`#release-form button[type="submit"]`).
			ExpectNoElement("#reserve-form").
			ExpectNoElement(`a[href]:not([href^="#"])`)
	})

	specs.Add("Participant releases a reserved seat", func(bld *spec.B) {
		bld.Given(workshop, aliceReserved)
		bld.When(spec.Post("/workshops/october/release", spec.Form{"email": " Alice@Example.COM "})).
			Then("the release is recorded for the normalized email and redirects to its status").
			Covers("W13", "W3").
			ExpectRedirect("/workshops/october?email=alice%40example.com").
			ExpectEvents(aliceReleased)
	})

	for _, example := range []struct {
		name    string
		history []evt.Event
	}{
		{"without a reservation", []evt.Event{workshop}},
		{"after already releasing", []evt.Event{workshop, aliceReserved, aliceReleased}},
		{"while another email holds the last seat", []evt.Event{workshop, evt.SeatReserved{WorkshopID: "october", Email: "bob@example.com"}}},
	} {
		specs.Add("Participant releases "+example.name, func(bld *spec.B) {
			bld.Given(example.history...)
			bld.When(spec.Post("/workshops/october/release", spec.Form{"email": " ALICE@example.com "})).
				Then("an unreserved email succeeds without recording a release").
				Covers("W13").
				ExpectRedirect("/workshops/october?email=alice%40example.com").
				ExpectNoEvents()
		})
	}

	for _, example := range []struct{ name, email string }{
		{"missing email", ""},
		{"whitespace email", "   "},
		{"malformed email", "not-an-email"},
		{"email with a display name", "Alice <alice@example.com>"},
		{"multiple email addresses", "alice@example.com,bob@example.com"},
	} {
		specs.Add("Participant submits an invalid release: "+example.name, func(bld *spec.B) {
			bld.Given(workshop, aliceReserved)
			bld.When(spec.Post("/workshops/october/release", spec.Form{"email": example.email})).
				Then("invalid email releases nothing and can be corrected on the participant page").
				Covers("W13", "W12", "W2").
				ExpectStatus(http.StatusBadRequest).
				ExpectNoEvents().
				ExpectEl("#email", spec.With{"value": example.email}).
				ExpectEl("#email-error").
				ExpectEl("form:has(#email)", spec.With{"method": "get", "action": "/workshops/october"}).
				ExpectNoElement("#reservation-status, #reserve-form, #release-form").
				ExpectNoElement(`a[href]:not([href^="#"])`)
		})
	}

	specs.Add("Participant releases a seat in an unknown workshop", func(bld *spec.B) {
		bld.Given(workshop, aliceReserved)
		bld.When(spec.Post("/workshops/missing/release", spec.Form{"email": "alice@example.com"})).
			Then("an unknown workshop cannot receive a release").
			Covers("W9", "W13").
			ExpectStatus(http.StatusNotFound).
			ExpectNoEvents()
	})

	for _, email := range []string{"alice", "bob"} {
		specs.Add("Participant "+email+" checks availability after a release", func(bld *spec.B) {
			bld.Given(workshop, aliceReserved, aliceReleased)
			bld.When(spec.Get("/workshops/october?email="+email+"%40example.com")).
				Then("the seat is available to the released email and other visitors").
				Covers("W14", "W2").
				ExpectEl("#remaining", spec.With{"text": "1"}).
				ExpectEl("#reservation-status", spec.With{"data-status": "not-reserved"}).
				ExpectEl("#reserve-form", spec.With{"method": "post", "action": "/workshops/october/reserve"}).
				ExpectEl(`#reserve-form input[name="email"]`, spec.With{"value": email + "@example.com"}).
				ExpectNoElement("#release-form, #workshop-full").
				ExpectNoElement(`a[href]:not([href^="#"])`)
		})
		specs.Add("Participant "+email+" reserves the released seat", func(bld *spec.B) {
			bld.Given(workshop, aliceReserved, aliceReleased)
			bld.When(spec.Post("/workshops/october/reserve", spec.Form{"email": email + "@example.com"})).
				Then("the released seat can be reserved again").
				Covers("W14", "W4").
				ExpectRedirect("/workshops/october?email=" + email + "%40example.com").
				ExpectEvents(evt.SeatReserved{WorkshopID: "october", Email: email + "@example.com"})
		})
	}

	specs.Add("Participant opens a workshop after a release without an email", func(bld *spec.B) {
		bld.Given(workshop, aliceReserved, aliceReleased)
		bld.When(spec.Get("/workshops/october")).
			Then("release remains unavailable until a reserved email is checked").
			Covers("W13", "W2").
			ExpectNoElement("#reservation-status, #reserve-form, #release-form")
	})

	specs.Add("Organizer reads the catalogue after a release", func(bld *spec.B) {
		bld.Given(workshop, aliceReserved, aliceReleased)
		bld.When(spec.Get("/")).
			Then("the formerly full workshop shows reduced occupancy and is available").
			Covers("W14", "W8").
			ExpectVisibleText(workshopCatalogueRow("october"), "0 / 1 reserved", "1 remaining", "Available").
			ExpectNoText("Full")
	})

	specs.Add("Organizer reads occupancy after a release", func(bld *spec.B) {
		bld.Given(workshop, aliceReserved, aliceReleased)
		bld.When(spec.Get("/workshops/october/reservations")).
			Then("the organizer sees the released seat in the current counts").
			Covers("W14", "W11").
			ExpectEl("#reserved", spec.With{"text": "0"}).
			ExpectEl("#capacity", spec.With{"text": "1"}).
			ExpectEl("#remaining", spec.With{"text": "1"})
	})

	specs.Add("Organizer reads reservations after one participant releases", func(bld *spec.B) {
		bld.Given(
			evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 2},
			aliceReserved,
			evt.SeatReserved{WorkshopID: "october", Email: "bob@example.com"},
			aliceReleased,
		)
		bld.When(spec.Get("/workshops/october/reservations")).
			Then("only the released email leaves the reservations list").
			Covers("W14", "W11").
			ExpectTexts("[data-reservation]", "bob@example.com")
	})

	specs.Add("Participant checks the same email in another workshop after a release", func(bld *spec.B) {
		bld.Given(
			workshop, aliceReserved,
			evt.WorkshopCreated{WorkshopID: "november", Title: "Foundations", Capacity: 1},
			evt.SeatReserved{WorkshopID: "november", Email: "alice@example.com"},
			aliceReleased,
		)
		bld.When(spec.Get("/workshops/november?email=alice%40example.com")).
			Then("releasing one workshop leaves the other reservation and occupancy unchanged").
			Covers("W14", "W7").
			ExpectEl("#reservation-status", spec.With{"data-status": "reserved"}).
			ExpectEl("#remaining", spec.With{"text": "0"})
	})

	return specs
}
