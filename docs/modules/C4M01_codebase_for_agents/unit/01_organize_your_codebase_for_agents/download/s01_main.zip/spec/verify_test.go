package spec

import (
	"ai_code_october_specs/evt"
	"errors"
	"strings"
	"testing"
)

func TestElementProperties(t *testing.T) {
	for _, example := range []struct {
		name     string
		body     string
		check    Expectation
		failures []string
	}{
		{
			name:  "selected attributes ignore additional properties and preserve whitespace",
			body:  `<input id="field" value="  Event Storming  " required type="text" class="input">`,
			check: El("#field", With{"value": "  Event Storming  ", "type": "text"}),
		},
		{
			name:  "empty values and boolean attributes are present",
			body:  `<input id="field" value="" required>`,
			check: El("#field", With{"value": "", "required": ""}),
		},
		{
			name:     "empty does not mean absent",
			body:     `<input id="field">`,
			check:    El("#field", With{"value": ""}),
			failures: []string{`HTML selector "#field"`, `value: expected "" got <unset>`},
		},
		{
			name:     "all mismatched properties are reported",
			body:     `<input id="field" value="9" type="text">`,
			check:    El("#field", With{"value": "0", "type": "number"}),
			failures: []string{`type: expected "number" got "text"`, `value: expected "0" got "9"`},
		},
		{
			name:     "properties require exactly one element",
			body:     `<input value="0"><input value="0">`,
			check:    El("input", With{"value": "0"}),
			failures: []string{"element count: input", "want: 1", "got: 2"},
		},
		{
			name:     "missing element cannot satisfy properties",
			body:     `<main></main>`,
			check:    El("input", With{"value": "0"}),
			failures: []string{"element count: input", "got: 0"},
		},
		{
			name:  "text properties distinguish normalized and exact content",
			body:  "<p id=field>  Hello\n world  </p>",
			check: El("#field", With{"text": "Hello world", "text.exact": "  Hello\n world  "}),
		},
		{
			name:     "exact text does not normalize whitespace",
			body:     "<p id=field>  Hello\n world  </p>",
			check:    El("#field", With{"text.exact": "Hello world"}),
			failures: []string{`["text.exact"]: expected "Hello world" got "  Hello\n world  "`},
		},
		{
			name:  "existence allows several matches",
			body:  `<input><input>`,
			check: El("input"),
		},
		{
			name:     "existence still requires a match",
			body:     `<main></main>`,
			check:    El("input"),
			failures: []string{`HTML selector "input" matched no elements`},
		},
	} {
		t.Run(example.name, func(t *testing.T) {
			err := verifyBody(example.body, example.check)
			if len(example.failures) == 0 {
				if err != nil {
					t.Fatal(err)
				}
				return
			}
			if err == nil {
				t.Fatal("mismatched element passed")
			}
			for _, failure := range example.failures {
				if !strings.Contains(err.Error(), failure) {
					t.Errorf("missing failure %q in %v", failure, err)
				}
			}
		})
	}
}

func TestElementPropertiesAreCapturedAtDefinition(t *testing.T) {
	properties := With{"value": "original"}
	check := El("input", properties)
	properties["value"] = "changed"
	if err := verifyBody(`<input value="original">`, check); err != nil {
		t.Fatal(err)
	}
}

func TestVisibleTextFragments(t *testing.T) {
	body := `<ul><li><a href="/workshops/october/reservations">Executable Specs</a><p>1 / 1 reserved</p><small>0 remaining</small><span>Full</span></li></ul>`
	selector := `li:has(a[href="/workshops/october/reservations"])`

	if err := verifyBody(body, VisibleText(selector, "1 / 1 reserved", "0 remaining", "Full")); err != nil {
		t.Fatal(err)
	}
	err := verifyBody(body, VisibleText(selector, "Available"))
	if err == nil || !strings.Contains(err.Error(), `missing: ["Available"]`) {
		t.Fatalf("missing visible text: %v", err)
	}
}

func TestObjectMapComparisonRetainsExplicitValues(t *testing.T) {
	want := map[string]any{"seats": 0, "reason": "", "feedback": nil, "enabled": false}
	got := map[string]any{"seats": 0, "reason": "", "feedback": nil, "enabled": false, "extra": "ignored"}
	if err := compareFields("object", want, got); err != nil {
		t.Fatal(err)
	}
	delete(got, "feedback")
	if err := compareFields("object", want, got); err == nil || !strings.Contains(err.Error(), "feedback: expected null got <unset>") {
		t.Fatalf("missing is not null: %v", err)
	}
}

func TestEventExpectationsKeepTheirMatchingBoundary(t *testing.T) {
	oneSeat := evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1}
	aliceReserved := evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"}
	bobReserved := evt.SeatReserved{WorkshopID: "october", Email: "bob@example.com"}
	for _, example := range []struct {
		name string
		got  []evt.Event
		want []evt.Event
		pass bool
	}{
		{"no events", nil, nil, true},
		{"exact fields", []evt.Event{aliceReserved}, []evt.Event{aliceReserved}, true},
		{"generated fields may be omitted", []evt.Event{oneSeat}, []evt.Event{evt.WorkshopCreated{Title: oneSeat.Title}}, true},
		{"extra events before between and after", []evt.Event{oneSeat, aliceReserved, oneSeat, bobReserved, oneSeat}, []evt.Event{aliceReserved, bobReserved}, true},
		{"same type with different fields is skipped", []evt.Event{bobReserved, aliceReserved}, []evt.Event{aliceReserved}, true},
		{"additional matching events are allowed", []evt.Event{aliceReserved, aliceReserved}, []evt.Event{aliceReserved}, true},
		{"matching event cannot be reused", []evt.Event{aliceReserved}, []evt.Event{aliceReserved, aliceReserved}, false},
		{"omitted zero field does not constrain event", []evt.Event{oneSeat}, []evt.Event{evt.WorkshopCreated{Capacity: 0}}, true},
		{"extra event", []evt.Event{aliceReserved}, nil, false},
		{"missing event", nil, []evt.Event{aliceReserved}, false},
		{"wrong event type", []evt.Event{oneSeat}, []evt.Event{evt.SeatReserved{}}, false},
		{"wrong populated field", []evt.Event{bobReserved}, []evt.Event{aliceReserved}, false},
		{"wrong order", []evt.Event{aliceReserved, bobReserved}, []evt.Event{bobReserved, aliceReserved}, false},
	} {
		t.Run(example.name, func(t *testing.T) {
			err := errors.Join(Verify([]Expectation{Events(example.want...)}, Result{Events: example.got})...)
			if (err == nil) != example.pass {
				t.Fatalf("want pass=%v, got %v", example.pass, err)
			}
		})
	}
}

func TestEventFieldMismatchRemainsDiagnostic(t *testing.T) {
	err := errors.Join(Verify([]Expectation{Events(evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"})}, Result{
		Events: []evt.Event{
			evt.WorkshopCreated{WorkshopID: "october"},
			evt.SeatReserved{WorkshopID: "november", Email: "bob@example.com"},
		},
	})...)
	if err == nil {
		t.Fatal("mismatched event passed")
	}
	for _, fragment := range []string{`event 1 evt.SeatReserved`, `workshop_id: expected "october" got "november"`, `email: expected "alice@example.com" got "bob@example.com"`} {
		if !strings.Contains(err.Error(), fragment) {
			t.Errorf("missing %q in %v", fragment, err)
		}
	}
}

func verifyBody(body string, check Expectation) error {
	return errors.Join(Verify([]Expectation{check}, Result{Body: []byte(body)})...)
}
