package specs

import "ai_code_october_specs/spec"

var Features = []spec.Feature{
	{Name: "Workshop creation", Specs: workshopCreationSpecs()},
	{Name: "Participant reservations", Specs: participantReservationSpecs()},
	{Name: "Workshop catalogue", Specs: workshopCatalogueSpecs()},
	{Name: "Unknown workshops", Specs: unknownWorkshopSpecs()},
	{Name: "Organizer navigation", Specs: organizerNavigationSpecs()},
	{Name: "Organizer reservations", Specs: organizerReservationSpecs()},
}
