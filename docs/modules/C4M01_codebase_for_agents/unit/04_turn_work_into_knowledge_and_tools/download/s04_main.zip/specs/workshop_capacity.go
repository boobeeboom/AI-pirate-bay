package specs

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/spec"
	"net/http"
)

func workshopCapacitySpecs() spec.Specs {
	var specs spec.Specs
	workshop := evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 3}
	alice := evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"}
	bob := evt.SeatReserved{WorkshopID: "october", Email: "bob@example.com"}

	specs.Add("Visitor opens the capacity form", func(bld *spec.B) {
		bld.Given(workshop, alice, bob)
		bld.When(spec.Get("/workshops/october/reservations")).
			Then("the reservations page offers the current total for editing").
			Covers("W15", "W11").
			ExpectEl(`form:has(input[name="capacity"])`, spec.With{"method": "post", "action": "/workshops/october/capacity"}).
			ExpectEl(`form input[name="capacity"]`, spec.With{"value": "3"})
	})

	specs.Add("Visitor increases workshop capacity", func(bld *spec.B) {
		bld.Given(workshop, alice)
		bld.When(spec.Post("/workshops/october/capacity", spec.Form{"capacity": "4"})).
			Then("the new total is recorded and the visitor returns to reservations").
			Covers("W15").
			ExpectRedirect("/workshops/october/reservations").
			ExpectEvents(evt.WorkshopCapacityChanged{WorkshopID: "october", Capacity: 4})
	})

	specs.Add("Visitor reduces capacity to the number of reservations", func(bld *spec.B) {
		bld.Given(workshop, alice, bob)
		bld.When(spec.Post("/workshops/october/capacity", spec.Form{"capacity": "2"})).
			Then("the workshop can become full without removing reservations").
			Covers("W15").
			ExpectRedirect("/workshops/october/reservations").
			ExpectEvents(evt.WorkshopCapacityChanged{WorkshopID: "october", Capacity: 2})
	})

	specs.Add("Visitor submits the current capacity", func(bld *spec.B) {
		bld.Given(workshop, alice)
		bld.When(spec.Post("/workshops/october/capacity", spec.Form{"capacity": "3"})).
			Then("an unchanged total needs no new event").
			Covers("W15").
			ExpectRedirect("/workshops/october/reservations").
			ExpectNoEvents()
	})

	specs.Add("Visitor requests fewer seats than are reserved", func(bld *spec.B) {
		bld.Given(workshop, alice, bob)
		bld.When(spec.Post("/workshops/october/capacity", spec.Form{"capacity": "1"})).
			Then("existing reservations set the minimum and the visitor can correct the request").
			Covers("W15", "W12").
			ExpectStatus(http.StatusConflict).
			ExpectNoEvents().
			ExpectEl(`form input[name="capacity"]`, spec.With{"value": "1"}).
			ExpectEl("#capacity-error")
	})

	for _, example := range []struct {
		name   string
		fields spec.Form
		value  string
	}{
		{"missing capacity", spec.Form{}, ""},
		{"zero capacity", spec.Form{"capacity": "0"}, "0"},
		{"negative capacity", spec.Form{"capacity": "-1"}, "-1"},
		{"fractional capacity", spec.Form{"capacity": "1.5"}, "1.5"},
	} {
		specs.Add("Visitor submits invalid capacity: "+example.name, func(bld *spec.B) {
			bld.Given(workshop, alice)
			bld.When(spec.Post("/workshops/october/capacity", example.fields)).
				Then("invalid capacity records nothing and can be corrected in place").
				Covers("W15", "W12").
				ExpectStatus(http.StatusBadRequest).
				ExpectNoEvents().
				ExpectEl(`form input[name="capacity"]`, spec.With{"value": example.value}).
				ExpectEl("#capacity-error")
		})
	}

	changed := evt.WorkshopCapacityChanged{WorkshopID: "october", Capacity: 4}
	specs.Add("Organizer reads occupancy after a capacity change", func(bld *spec.B) {
		bld.Given(workshop, alice, bob, evt.WorkshopCapacityChanged{WorkshopID: "october", Capacity: 2})
		bld.When(spec.Get("/workshops/october/reservations")).
			Then("reducing the total to occupancy keeps both reservations and makes the workshop full").
			Covers("W15", "W11").
			ExpectEl("#reserved", spec.With{"text": "2"}).
			ExpectEl("#capacity", spec.With{"text": "2"}).
			ExpectEl("#remaining", spec.With{"text": "0"}).
			ExpectTexts("[data-reservation]", "alice@example.com", "bob@example.com")
	})

	specs.Add("Organizer reads the catalogue after a capacity change", func(bld *spec.B) {
		bld.Given(workshop, alice, changed)
		bld.When(spec.Get("/")).
			Then("the new total determines visible availability").
			Covers("W15", "W8").
			ExpectVisibleText(workshopCatalogueRow("october"), "1 / 4 reserved", "3 remaining", "Available")
	})

	specs.Add("Participant checks availability after a capacity increase", func(bld *spec.B) {
		bld.Given(
			evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1},
			alice,
			evt.WorkshopCapacityChanged{WorkshopID: "october", Capacity: 2},
		)
		bld.When(spec.Get("/workshops/october?email=bob%40example.com")).
			Then("an added seat is available to another participant").
			Covers("W15", "W2", "W3").
			ExpectEl("#capacity", spec.With{"text": "2"}).
			ExpectEl("#remaining", spec.With{"text": "1"}).
			ExpectEl("#reserve-form", spec.With{"action": "/workshops/october/reserve"})
	})

	return specs
}
