package specs

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/spec"
	"net/http"
	"net/url"
)

func participantReservationSpecs() spec.Specs {
	var specs spec.Specs

	specs.Add("Participant follows a workshop link", func(bld *spec.B) {
		bld.Given(
			evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 2},
			evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"},
		)
		bld.When(spec.Get("/workshops/october")).
			Then("only the workshop and reservation flow are visible before entering an email").
			Covers("W2").
			ExpectEl("h1", spec.With{"text": "Executable Specs"}).
			ExpectEl("#remaining", spec.With{"text": "1"}).
			ExpectEl("#capacity", spec.With{"text": "2"}).
			ExpectNoElement(`a[href]:not([href^="#"])`).
			ExpectNoElement("#primary-nav, #breadcrumbs, #workshop-nav, #share-link").
			ExpectEl("form:has(#email)", spec.With{"method": "get"}).
			ExpectEl("form input#email", spec.With{"name": "email"}).
			ExpectNoElement("#reserve-form").
			ExpectNoText(evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"}.Email)
	})

	specs.Add("Participant reads a workshop title containing HTML", func(bld *spec.B) {
		bld.Given(evt.WorkshopCreated{WorkshopID: "html", Title: "<script>alert(1)</script>", Capacity: 1})
		bld.When(spec.Get("/workshops/html")).
			Then("user-provided titles are displayed without creating executable HTML").
			Covers("W2").
			ExpectEl("h1", spec.With{"text": "<script>alert(1)</script>"}).
			ExpectNoElement("script")
	})

	specs.Add("Participant checks an unreserved email", func(bld *spec.B) {
		bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1})
		bld.When(spec.Get("/workshops/october?email=alice%40example.com")).
			Then("checking status offers a reservation without reserving a seat").
			Covers("W3", "W2").
			ExpectEl("#remaining", spec.With{"text": "1"}).
			ExpectNoElement(`a[href]:not([href^="#"])`).
			ExpectEl("#reservation-status", spec.With{"data-status": "not-reserved"}).
			ExpectEl("#reserve-form", spec.With{"method": "post", "action": "/workshops/october/reserve"}).
			ExpectEl(`#reserve-form input[name="email"]`, spec.With{"value": "alice@example.com"})
	})

	for _, example := range []struct{ name, email string }{
		{"missing email", ""},
		{"malformed email", "not-an-email"},
		{"email with a display name", "Alice <alice@example.com>"},
		{"multiple email addresses", "alice@example.com,bob@example.com"},
	} {
		specs.Add("Participant submits an invalid reservation: "+example.name, func(bld *spec.B) {
			bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1})
			bld.When(spec.Post("/workshops/october/reserve", spec.Form{"email": example.email})).
				Then("invalid email creates no reservation and can be corrected in place").
				Covers("W4", "W12", "W2").
				ExpectStatus(http.StatusBadRequest).
				ExpectNoEvents().
				ExpectNoElement(`a[href]:not([href^="#"])`).
				ExpectEl("#email", spec.With{"value": example.email}).
				ExpectElementCount("#email-error", 1).
				ExpectNoElement("#reservation-status").
				ExpectNoElement("#reserve-form")
		})
		if example.email != "" {
			specs.Add("Participant submits an invalid status lookup: "+example.name, func(bld *spec.B) {
				bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1})
				bld.When(spec.Get("/workshops/october?email="+url.QueryEscape(example.email))).
					Then("invalid email is reported without changing history or losing the input").
					Covers("W3", "W12", "W2").
					ExpectStatus(http.StatusBadRequest).
					ExpectNoEvents().
					ExpectNoElement(`a[href]:not([href^="#"])`).
					ExpectEl("#email", spec.With{"value": example.email}).
					ExpectElementCount("#email-error", 1).
					ExpectNoElement("#reservation-status").
					ExpectNoElement("#reserve-form")
			})
		}
	}

	specs.Add("Participant reserves the last available seat", func(bld *spec.B) {
		bld.Given(evt.WorkshopCreated{
			WorkshopID: "october",
			Title:      "Executable Specs",
			Capacity:   1})
		bld.When(spec.Post("/workshops/october/reserve", spec.Form{"email": " Alice@Example.COM "})).
			Then("the reservation is recorded with the normalized email").
			Covers("W4", "W3").
			ExpectRedirect("/workshops/october?email=alice%40example.com").
			ExpectEvents(evt.SeatReserved{
				WorkshopID: "october",
				Email:      "alice@example.com"})
	})

	specs.Add("Participant checks a reserved email", func(bld *spec.B) {
		bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1}, evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"})
		bld.When(spec.Get("/workshops/october?email=ALICE%40EXAMPLE.COM")).
			Then("the reservation remains visible when no seats remain").
			Covers("W4", "W3", "W2").
			ExpectEl("#remaining", spec.With{"text": "0"}).
			ExpectNoElement(`a[href]:not([href^="#"])`).
			ExpectEl("#reservation-status", spec.With{"data-status": "reserved"}).
			ExpectNoElement("#reserve-form")
	})

	specs.Add("Participant retries a reservation while the workshop is full", func(bld *spec.B) {
		bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1}, evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"})
		bld.When(spec.Post("/workshops/october/reserve", spec.Form{"email": " ALICE@example.com "})).
			Then("the existing reservation succeeds without another event").
			Covers("W5").
			ExpectRedirect("/workshops/october?email=alice%40example.com").
			ExpectNoEvents()
	})

	specs.Add("Participant retries a reservation while other seats remain", func(bld *spec.B) {
		bld.Given(
			evt.WorkshopCreated{WorkshopID: "october", Title: "Specs", Capacity: 2},
			evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"},
		)
		bld.When(spec.Post("/workshops/october/reserve", spec.Form{"email": "alice@example.com"})).
			Then("a retry never consumes an additional seat").
			Covers("W5").
			ExpectRedirect("/workshops/october?email=alice%40example.com").
			ExpectNoEvents()
	})

	specs.Add("Participant requests a seat in a full workshop", func(bld *spec.B) {
		bld.Given(
			evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1},
			evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"})
		bld.When(spec.Post("/workshops/october/reserve", spec.Form{"email": "bob@example.com"})).
			Then("the visitor sees full and remains unreserved").
			Covers("W6", "W2").
			ExpectStatus(http.StatusConflict).
			ExpectNoEvents().
			ExpectEl("#remaining", spec.With{"text": "0"}).
			ExpectNoElement(`a[href]:not([href^="#"])`).
			ExpectElementCount("#workshop-full", 1).
			ExpectEl("#reservation-status", spec.With{"data-status": "not-reserved"}).
			ExpectNoElement("#reserve-form")
	})

	specs.Add("Participant checks an unreserved email in a full workshop", func(bld *spec.B) {
		bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1}, evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"})
		bld.When(spec.Get("/workshops/october?email=bob%40example.com")).
			Then("the page explains availability without offering a reservation").
			Covers("W6").
			ExpectElementCount("#workshop-full", 1).
			ExpectNoElement("#reserve-form").
			ExpectEl("#reservation-status", spec.With{"data-status": "not-reserved"})
	})

	specs.Add("Participant reserves another workshop independently", func(bld *spec.B) {
		bld.Given(
			evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1},
			evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"},
			evt.WorkshopCreated{WorkshopID: "november", Title: "Foundations", Capacity: 1},
		)
		bld.When(spec.Post("/workshops/november/reserve", spec.Form{"email": "alice@example.com"})).
			Then("a reservation in one workshop does not consume a place in another").
			Covers("W7").
			ExpectRedirect("/workshops/november?email=alice%40example.com").
			ExpectEvents(evt.SeatReserved{WorkshopID: "november", Email: "alice@example.com"})
	})

	return specs
}
