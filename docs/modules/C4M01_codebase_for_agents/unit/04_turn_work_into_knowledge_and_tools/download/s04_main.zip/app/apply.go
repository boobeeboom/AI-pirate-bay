package app

import (
	"ai_code_october_specs/evt"
	"fmt"
)

// apply derives projections. It does not re-run today's command decisions.
func (tx *Tx) apply(event evt.Event) error {
	var err error
	switch event := event.(type) {
	case evt.WorkshopCreated:
		_, err = tx.Exec(`INSERT INTO workshops (id, title, capacity) VALUES (?, ?, ?)`,
			event.WorkshopID, event.Title, event.Capacity)
	case evt.WorkshopCapacityChanged:
		_, err = tx.Exec(`UPDATE workshops SET capacity = ? WHERE id = ?`,
			event.Capacity, event.WorkshopID)
	case evt.SeatReserved:
		_, err = tx.Exec(`INSERT INTO reservations (workshop_id, email) VALUES (?, ?)`,
			event.WorkshopID, event.Email)
	case evt.SeatReleased:
		_, err = tx.Exec(`DELETE FROM reservations WHERE workshop_id = ? AND email = ?`,
			event.WorkshopID, event.Email)
	default:
		return fmt.Errorf("unsupported event %T", event)
	}
	return err
}
