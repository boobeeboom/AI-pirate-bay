package specs

import "ai_code_october_specs/spec"

var Features = []spec.Feature{
	{Name: "Workshop creation", Specs: workshopCreationSpecs()},
	{Name: "Participant reservations", Specs: participantReservationSpecs()},
	{Name: "Release a seat", Specs: releaseSeatSpecs()},
	{Name: "Workshop catalogue", Specs: workshopCatalogueSpecs()},
	{Name: "Unknown workshops", Specs: unknownWorkshopSpecs()},
	{Name: "Organizer navigation", Specs: organizerNavigationSpecs()},
	{Name: "Organizer reservations", Specs: organizerReservationSpecs()},
	{Name: "Workshop capacity", Specs: workshopCapacitySpecs()},
}
