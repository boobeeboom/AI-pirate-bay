#!/usr/bin/env python3
"""outline.py FILE - show markdown outline with line ranges (use for large files)"""

import argparse
from pathlib import Path
import re


def sections(text):
    """ATX headings, with inclusive ranges that include nested sections."""
    rows = text.splitlines(keepends=True)
    offsets = [0]
    headings, stack, fence = [], [], None
    for number, row in enumerate(rows, 1):
        offsets.append(offsets[-1] + len(row.encode("utf-8")))
        line = row.rstrip("\r\n")
        marker = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", line)
        if fence:
            if marker and marker[1][0] == fence[0] and len(marker[1]) >= fence[1] and not marker[2].strip():
                fence = None
            continue
        if marker and (marker[1][0] != "`" or "`" not in marker[2]):
            fence = (marker[1][0], len(marker[1]))
            continue
        match = re.match(r"^ {0,3}(#{1,6})(?:[ \t]+(.*)|$)", line)
        if not match:
            continue
        title = re.sub(r"(?:^|[ \t]+)#+[ \t]*$", "", match[2] or "").strip()
        heading = {"line": number, "level": len(match[1]), "title": title}
        while stack and stack[-1]["level"] >= heading["level"]:
            stack.pop()["end"] = number - 1
        heading["depth"] = len(stack)
        stack.append(heading)
        headings.append(heading)
    for heading in stack:
        heading["end"] = len(rows)
    for heading in headings:
        heading["size"] = offsets[heading["end"]] - offsets[heading["line"] - 1]
    return rows, headings


def outline(path):
    data = path.read_bytes()
    rows, headings = sections(data.decode("utf-8"))
    output = [f"{path} · {len(rows):,} {'line' if len(rows) == 1 else 'lines'} · {len(data):,} bytes"]
    if not rows:
        output.append("  (empty)")
    elif not headings:
        output.append(f"  Text · L1–{len(rows)} · {len(data):,} bytes")
    elif headings[0]["line"] > 1:
        end = headings[0]["line"] - 1
        size = len("".join(rows[:end]).encode("utf-8"))
        output.append(f"  Intro · L1–{end} · {size:,} bytes")
    for heading in headings:
        indent = "  " * (heading["depth"] + 1)
        output.append(
            f"{indent}{'#' * heading['level']} {heading['title']} · "
            f"L{heading['line']}–{heading['end']} · {heading['size']:,} bytes"
        )
    return "\n".join(output)


def main():
    parser = argparse.ArgumentParser(
        description=__doc__,
        epilog=(
            "Recognizes # through ###### headings outside fenced code. "
            "Ranges are one-based and include the heading and its subsections. "
            "Read a range with your file reader or sed -n 'START,ENDp' FILE. "
            "Run the outline again after editing a file."
        ),
    )
    parser.add_argument("files", metavar="FILE", type=Path, nargs="+", help="UTF-8 Markdown files")
    args = parser.parse_args()
    try:
        print("Markdown outlines. Line ranges are 1-based and inclusive (e.g. for sed).\n")
        print("\n\n".join(outline(path) for path in args.files))
    except (OSError, UnicodeError) as error:
        parser.exit(1, f"{parser.prog}: {error}\n")


if __name__ == "__main__":
    main()
