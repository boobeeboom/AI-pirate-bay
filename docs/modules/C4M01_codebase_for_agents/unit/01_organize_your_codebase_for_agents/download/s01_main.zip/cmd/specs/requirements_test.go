package main

import (
	"ai_code_october_specs/spec"
	"bytes"
	"strings"
	"testing"
)

func TestRequirementValidationPrecedesExecution(t *testing.T) {
	for _, example := range []struct {
		name     string
		contract string
		links    []spec.RequirementID
		failure  string
	}{
		{"unknown link", "W1. Known requirement.", []spec.RequirementID{"W2"}, `unknown requirement "W2"`},
		{"missing link", "W1. Known requirement.", nil, "missing Covers requirements"},
		{"duplicate link", "W1. Known requirement.", []spec.RequirementID{"W1", "W1"}, "duplicate requirement W1"},
		{"duplicate requirement", "W1. First.\nW1. Second.", []spec.RequirementID{"W1"}, "line 2: duplicate requirement W1 (first at line 1)"},
		{"malformed requirement", "W01. Invalid.", []spec.RequirementID{"W1"}, `invalid requirement ID "W01"`},
		{"empty contract", "# No requirements", []spec.RequirementID{"W1"}, "no numbered requirements found"},
	} {
		t.Run(example.name, func(t *testing.T) {
			executed := false
			scenario := spec.New("invalid links", func(bld *spec.B) {
				bld.When(spec.Get("/")).Then("invalid links prevent execution").Expect(spec.Custom(func(spec.Result) error {
					executed = true
					return nil
				}))
			})
			scenario.Requirements = example.links
			var out bytes.Buffer
			code := runContract(t, nil, &out, []spec.Feature{{Name: "runner", Specs: []spec.Spec{scenario}}}, example.contract)
			if code != 2 || executed || !strings.Contains(out.String(), example.failure) {
				t.Fatalf("code=%d executed=%v, want validation failure %q:\n%s", code, executed, example.failure, out.String())
			}
		})
	}
}

func TestCoverageReportsAllInterpretationsInDocumentOrderAfterFailures(t *testing.T) {
	features := []spec.Feature{{Name: "runner", Specs: []spec.Spec{
		spec.New("passing", func(bld *spec.B) {
			bld.When(spec.Get("/")).Then("the catalogue is readable").Covers("W1", "W2")
		}),
		spec.New("failing", func(bld *spec.B) {
			bld.When(spec.Get("/missing")).Then("a missing page is readable").Covers("W2")
		}),
		spec.New("after failure", func(bld *spec.B) {
			bld.When(spec.Get("/")).Then("execution continues").Covers("W1")
		}),
	}}}
	var out bytes.Buffer
	code := runContract(t, []string{"-coverage"}, &out, features, "# Behavior\n\nW2. Second.\n\nW1. First.\n\nW3. No linked interpretation.")
	if code != 1 || !strings.Contains(out.String(), "3 scenarios: 2 passed, 1 failed") {
		t.Fatalf("failed run lost its outcome: code=%d\n%s", code, out.String())
	}
	_, report, found := strings.Cut(out.String(), "REQUIREMENT")
	if !found {
		t.Fatalf("no coverage report:\n%s", out.String())
	}
	var rows []string
	for _, line := range strings.Split(report, "\n")[1:] {
		if line = strings.Join(strings.Fields(line), " "); line != "" {
			rows = append(rows, line)
		}
	}
	want := []string{
		"W2 PASS runner / passing the catalogue is readable",
		"W2 FAIL runner / failing a missing page is readable",
		"W1 PASS runner / passing the catalogue is readable",
		"W1 PASS runner / after failure execution continues",
		"W3 NONE (no linked scenario) No linked interpretation.",
	}
	if strings.Join(rows, "\n") != strings.Join(want, "\n") {
		t.Fatalf("coverage rows:\n%s\nwant:\n%s", strings.Join(rows, "\n"), strings.Join(want, "\n"))
	}
}
