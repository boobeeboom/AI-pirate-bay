package specs

import (
	"ai_code_october_specs/spec"
	"net/http"
)

func unknownWorkshopSpecs() spec.Specs {
	var specs spec.Specs

	specs.Add("Participant opens an unknown workshop", func(bld *spec.B) {
		bld.When(spec.Get("/workshops/missing")).
			Then("an unknown link does not create a workshop").
			Covers("W9").
			ExpectStatus(http.StatusNotFound)
	})

	specs.Add("Participant reserves an unknown workshop", func(bld *spec.B) {
		bld.When(spec.Post("/workshops/missing/reserve", spec.Form{"email": "alice@example.com"})).
			Then("an unknown workshop cannot receive reservations").
			Covers("W9").
			ExpectStatus(http.StatusNotFound).
			ExpectNoEvents()
	})

	specs.Add("Organizer views reservations for an unknown workshop", func(bld *spec.B) {
		bld.When(spec.Get("/workshops/missing/reservations")).
			Then("an unknown workshop has no reservations page").
			Covers("W9").
			ExpectStatus(http.StatusNotFound)
	})

	return specs
}
