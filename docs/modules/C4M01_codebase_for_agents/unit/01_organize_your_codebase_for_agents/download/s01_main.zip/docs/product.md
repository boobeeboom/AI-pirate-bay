# Workshop Reservations

Workshop Reservations helps organizers publish workshops with limited capacity and lets participants reserve a place through a shared link. Organizers need to see who has reserved; participants need to see availability and know whether they have a place.

## Product concepts

- A **workshop** is an offering with a title and a limited number of seats.
- A **seat** is one unit of a workshop's capacity.
- A **reservation** associates an email address with a workshop and occupies one seat.
- An **email address** identifies a reservation. It does not establish the visitor's identity or prove ownership of the address.
- **Organizer** and **participant** describe how someone uses the product; they are not authenticated roles.

## Current scope

Visitors can create workshops, share their links, inspect availability, check reservation status, and reserve seats. The organizer catalogue shows workshops and availability, with a separate page for each workshop's reserved emails. A shared workshop link gives participants a self-contained reservation flow with no navigation to organizer pages or other reservations. This models a secret invitation link in the interface; the product has no authentication, and organizer pages remain accessible by URL. Anyone can act for an entered email.

The experience should make availability and reservation status clear with little effort. Product decisions should preserve that purpose as the application grows.

## Contract and development

`behavior.md` defines the accepted, observable contract beneath this vision. Executable specifications provide concrete interpretations of that contract, and the implementation delivers it. Differences between those layers require an explicit decision rather than silently changing one to match another.

Proposals live under `docs/features/` and state their status and unresolved questions. `release_a_seat.md` is currently proposed; it is not part of the accepted behavior or implemented product.
