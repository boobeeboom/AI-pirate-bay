# Release a seat

Status: accepted — contract in `behavior.md` W13–W14; executable scenarios in `specs/release_a_seat.go`.

## Intent

A participant who can no longer attend should be able to release their seat, making it available to someone else.

## Decisions

- Release is idempotent: an unreserved email succeeds without an event, including a retry after release.
- An existing reservation emits `SeatReleased`; the journal retains the original reservation. Replay removes only the matching workshop/email reservation from the projection.
- Released seats can be reserved again by the same email or someone else. Availability, participant status, catalogue counts, and organizer lists derive from current reservations.
- Command scenarios assert the durable event and redirect, or validation failure and no event. Page scenarios assert the resulting status, actions, counts, and lists separately.
