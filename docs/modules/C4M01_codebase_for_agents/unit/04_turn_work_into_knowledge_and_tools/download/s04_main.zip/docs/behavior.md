# Behavior contract

These are the accepted product requirements, guided by `product.md`. Executable scenarios in `specs/` interpret them. Proposed features remain separate until their behavior is agreed and incorporated into this contract.

## Workshop creation

W1. A visitor opens `/workshops/new` to create a workshop with a title and positive whole-number capacity. The form submits to `/workshops` and offers Cancel back to the catalogue. Trim surrounding title whitespace and reject an empty title. Successful creation records `WorkshopCreated` with a generated stable ID and returns HTTP 303 to `/workshops/{id}`. Invalid input returns 400 and records nothing.

## Participant reservation flow

W2. A shared workshop link at `/workshops/{id}` shows only the workshop title, total capacity, remaining seats, and the participant's reservation flow. User-provided titles render as text. Before an email is supplied, the page offers a status lookup. The page has no top bar, breadcrumbs, sharing prompt, links to other pages, or other participants' reservations. This remains true for lookup results, reservation confirmation, validation errors, and full-workshop responses. The organizer's reservations page provides the shareable link without an email attached.

W3. Checking an email is read-only. Trim surrounding whitespace and lowercase the entire address for this application's reservation identity. Accept one email address without a display name; this is syntactic validation, not proof of ownership or deliverability. Invalid nonempty lookup input returns 400. Empty lookup input shows the initial page. An unreserved email sees its status and, when a seat is available, a reservation form.

W4. Reserving an available seat records `SeatReserved` for that workshop and normalized email, then returns HTTP 303 to its status page. The page reports reserved and shows the resulting remaining count. Missing or invalid email input returns 400 and records nothing.

W5. Each email can hold at most one seat per workshop. Repeating a reservation succeeds with the same status destination and records no additional events. This remains true when the workshop is full.

W6. An unreserved email cannot reserve a full workshop. The command returns HTTP 409, shows full and not-reserved status, and records nothing. A normal GET of that state returns 200 and offers no reservation action. Concurrent requests for the last place cannot overbook it.

W7. Reservations in different workshops are independent, including when they use the same email.

## Catalogue, organizer pages, and request handling

W8. The root page lists workshops with their titles, reserved/total and remaining seat counts, and Available or Full status. Each workshop title links directly to its reservations page; there is no separate reservations action or participant link in the row. The catalogue links to New workshop; creation and reserved emails have their own pages. An empty catalogue offers a way to create the first workshop. All GET requests are read-only.

W9. Reading a workshop, viewing its reservations, reserving or releasing a seat, or changing capacity for an unknown workshop returns 404 and records nothing.

W10. The organizer's catalogue, creation, and reservations pages share a top bar with the product name linking home, Workshops navigation, and a New workshop action. The current navigation section is identified. Creation and reservations pages provide a breadcrumb back to Workshops; reservations also links to the participant's workshop page. The participant's page is self-contained as described in W2.

W11. `/workshops/{id}/reservations` identifies the workshop, shows reserved/total and remaining seat counts, and lists all reserved email addresses for that workshop. An empty list is explained. These pages are available without authentication.

W12. Validation failures render the relevant form with submitted field values retained and errors shown beside the invalid fields. Visitors can correct and resubmit without starting over. Invalid email input does not display a reservation status or offer a reservation or release action.

## Releasing seats

W13. A reserved email's participant status page offers a release form submitting to `/workshops/{id}/release`; other participant states offer no release action. Releasing uses the email normalization and validation in W3. An existing reservation records `SeatReleased` for that workshop and normalized email, then returns HTTP 303 to its status page. An unreserved email, including a repeated release, succeeds with the same destination and records nothing, even when the workshop is full. Missing or invalid email returns 400 and records nothing, with correction as in W12.

W14. A released seat becomes available immediately. The participant's status becomes not reserved and offers reservation when capacity remains; the same email or another email can reserve the seat under W4–W6. The catalogue and organizer's reservations page reflect the reduced occupancy, and the released email leaves that workshop's reservations list. Releasing affects neither other emails nor reservations in other workshops.

## Changing capacity

W15. The reservations page lets any visitor change a workshop's total capacity through a prefilled form posting to `/workshops/{id}/capacity`. Capacity remains a positive whole number and cannot fall below current reservations. Invalid numbers return 400; too few seats return 409. Both keep the submitted value for correction and record no event. A changed total records `WorkshopCapacityChanged` with the workshop ID and new capacity. Both valid submissions redirect 303 to the reservations page.

## Persistence boundary

The journal is authoritative. A command's decision reads, journal appends, and projection writes share one transaction. A failed transaction leaves neither partial events nor partial projected state. A successful HTTP response is published only after the transaction commits. Restarting the application preserves history and reconstructs projections from it.

Operation assumes one process with one SQLite connection. Requests within that process serialize through the connection.
