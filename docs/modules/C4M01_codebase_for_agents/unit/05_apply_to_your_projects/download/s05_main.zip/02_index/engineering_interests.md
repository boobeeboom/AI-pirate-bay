# Engineering interests

I want to apply and test AI Native Code principles in my projects. These are starting questions; incoming sources and project experience can change them.

- Progressive disclosure - how do we organize content so that a fresh agent (regardless of the architecture) can find the context it needs before making decisions? 
- **Spec-driven development:** How do I preserve intended behavior as requirements, specifications, and implementation change? [Current thread](arcs/preserving_behavior_across_feature_changes.md).
- **Iterative improvement:** Which changes make subsequent agent sessions more effective?
- Migrating legacy/inherited systems. How can we make an existing system understandable and safe to change? Or bring it up-to-the-speed with the latest practices
- How do we keep the system coherent as generating and changing code becomes cheaper? How do we leverage changed economics of development (with coding agents)
- Shared learning. What and how can travel between projects and people, and what needs local adaptation?
- Miscellaneous tips and tricks
