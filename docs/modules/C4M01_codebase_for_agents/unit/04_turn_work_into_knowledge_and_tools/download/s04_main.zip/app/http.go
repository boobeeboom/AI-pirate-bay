package app

import (
	"ai_code_october_specs/evt"
	"crypto/rand"
	"database/sql"
	"errors"
	"log"
	"net/http"
	"net/mail"
	"net/url"
	"strconv"
	"strings"
)

type response struct {
	status   int
	location string
	body     []byte
}

func Handler(store *Store) http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /{$}", handle(store, home))
	mux.HandleFunc("GET /workshops/new", handle(store, showCreation))
	mux.HandleFunc("POST /workshops", handle(store, createWorkshop))
	mux.HandleFunc("GET /workshops/{id}", handle(store, showWorkshop))
	mux.HandleFunc("GET /workshops/{id}/reservations", handle(store, showReservations))
	mux.HandleFunc("POST /workshops/{id}/capacity", handle(store, changeCapacity))
	mux.HandleFunc("POST /workshops/{id}/reserve", handle(store, reserveSeat))
	mux.HandleFunc("POST /workshops/{id}/release", handle(store, releaseSeat))
	mux.HandleFunc("GET /style.css", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "text/css; charset=utf-8")
		body, _ := assets.ReadFile("style.css")
		_, _ = w.Write(body)
	})
	return http.NewCrossOriginProtection().Handler(mux)
}

func handle(store *Store, action func(*Tx, *http.Request) (response, error)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		r.Body = http.MaxBytesReader(w, r.Body, 64<<10)
		var result response
		err := store.Transact(r.Context(), func(tx *Tx) error {
			var err error
			result, err = action(tx, r)
			return err
		})
		if err != nil {
			log.Printf("%s %s: %v", r.Method, r.URL.Path, err)
			http.Error(w, "The request could not be completed.", http.StatusInternalServerError)
			return
		}
		if result.location != "" {
			http.Redirect(w, r, result.location, result.status)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.WriteHeader(result.status)
		_, _ = w.Write(result.body)
	}
}

func home(tx *Tx, _ *http.Request) (response, error) {
	workshops, err := tx.workshops()
	if err != nil {
		return response{}, err
	}
	return render("home", "Workshops", workshops, http.StatusOK)
}

func showCreation(_ *Tx, _ *http.Request) (response, error) {
	return render("new_workshop", "New workshop", creationForm{}, http.StatusOK)
}

func createWorkshop(tx *Tx, r *http.Request) (response, error) {
	if err := r.ParseForm(); err != nil {
		return render("new_workshop", "New workshop", creationForm{FormError: "The form could not be read. Please try again."}, http.StatusBadRequest)
	}
	form := creationForm{Title: r.PostForm.Get("title"), Capacity: r.PostForm.Get("capacity")}
	title := strings.TrimSpace(form.Title)
	capacity, err := strconv.Atoi(form.Capacity)
	if title == "" {
		form.TitleError = "Enter a workshop title."
	}
	if err != nil || capacity < 1 {
		form.CapacityError = "Enter a positive whole number."
	}
	if form.TitleError != "" || form.CapacityError != "" {
		return render("new_workshop", "New workshop", form, http.StatusBadRequest)
	}
	id := rand.Text()
	if err := tx.Emit(evt.WorkshopCreated{WorkshopID: id, Title: title, Capacity: capacity}); err != nil {
		return response{}, err
	}
	return response{status: http.StatusSeeOther, location: "/workshops/" + id}, nil
}

func normalizeEmail(raw string) (string, error) {
	email := strings.ToLower(strings.TrimSpace(raw))
	address, err := mail.ParseAddress(email)
	if err != nil || address.Address != email || address.Name != "" {
		return "", errors.New("enter one email address without a display name")
	}
	return email, nil
}

func showWorkshop(tx *Tx, r *http.Request) (response, error) {
	workshop, err := tx.workshop(r.PathValue("id"))
	if errors.Is(err, sql.ErrNoRows) {
		return problem(http.StatusNotFound, "Workshop not found.")
	}
	if err != nil {
		return response{}, err
	}
	page := workshopPage{Workshop: workshop}
	if raw := r.URL.Query().Get("email"); raw != "" {
		page.Email, err = normalizeEmail(raw)
		if err != nil {
			page.Email, page.EmailError = raw, "Enter one valid email address without a display name."
			return render("workshop", workshop.Title, page, http.StatusBadRequest)
		}
		page.Reserved, err = tx.isReserved(workshop.ID, page.Email)
		if err != nil {
			return response{}, err
		}
	}
	return render("workshop", workshop.Title, page, http.StatusOK)
}

func showReservations(tx *Tx, r *http.Request) (response, error) {
	workshop, err := tx.workshop(r.PathValue("id"))
	if errors.Is(err, sql.ErrNoRows) {
		return problem(http.StatusNotFound, "Workshop not found.")
	}
	if err != nil {
		return response{}, err
	}
	return reservationsResponse(tx, workshop, strconv.Itoa(workshop.Capacity), "", http.StatusOK)
}

func reservationsResponse(tx *Tx, workshop Workshop, capacityValue, capacityError string, status int) (response, error) {
	emails, err := tx.reservationEmails(workshop.ID)
	if err != nil {
		return response{}, err
	}
	return render("reservations", "Reservations · "+workshop.Title, reservationsPage{
		Workshop: workshop, Emails: emails, CapacityValue: capacityValue, CapacityError: capacityError,
	}, status)
}

func changeCapacity(tx *Tx, r *http.Request) (response, error) {
	workshop, err := tx.workshop(r.PathValue("id"))
	if errors.Is(err, sql.ErrNoRows) {
		return problem(http.StatusNotFound, "Workshop not found.")
	}
	if err != nil {
		return response{}, err
	}
	if err := r.ParseForm(); err != nil {
		return reservationsResponse(tx, workshop, strconv.Itoa(workshop.Capacity), "The form could not be read. Please try again.", http.StatusBadRequest)
	}
	value := r.PostForm.Get("capacity")
	capacity, err := strconv.Atoi(value)
	if err != nil || capacity < 1 {
		return reservationsResponse(tx, workshop, value, "Enter a positive whole number.", http.StatusBadRequest)
	}
	if capacity < workshop.ReservedCount() {
		return reservationsResponse(tx, workshop, value, "Capacity cannot be less than the number of reserved seats.", http.StatusConflict)
	}
	if capacity != workshop.Capacity {
		if err := tx.Emit(evt.WorkshopCapacityChanged{WorkshopID: workshop.ID, Capacity: capacity}); err != nil {
			return response{}, err
		}
	}
	return response{status: http.StatusSeeOther, location: "/workshops/" + workshop.ID + "/reservations"}, nil
}

func reserveSeat(tx *Tx, r *http.Request) (response, error) {
	workshop, err := tx.workshop(r.PathValue("id"))
	if errors.Is(err, sql.ErrNoRows) {
		return problem(http.StatusNotFound, "Workshop not found.")
	}
	if err != nil {
		return response{}, err
	}
	if err := r.ParseForm(); err != nil {
		return render("workshop", workshop.Title, workshopPage{Workshop: workshop, EmailError: "The form could not be read. Enter your email again."}, http.StatusBadRequest)
	}
	email, err := normalizeEmail(r.PostForm.Get("email"))
	if err != nil {
		return render("workshop", workshop.Title, workshopPage{
			Workshop: workshop, Email: r.PostForm.Get("email"), EmailError: "Enter one valid email address without a display name.",
		}, http.StatusBadRequest)
	}
	reserved, err := tx.isReserved(workshop.ID, email)
	if err != nil {
		return response{}, err
	}
	// Check identity before capacity: retrying an existing reservation succeeds
	// even if that reservation took the final seat.
	if !reserved {
		if workshop.Remaining == 0 {
			return render("workshop", workshop.Title, workshopPage{Workshop: workshop, Email: email}, http.StatusConflict)
		}
		if err := tx.Emit(evt.SeatReserved{WorkshopID: workshop.ID, Email: email}); err != nil {
			return response{}, err
		}
	}
	return response{
		status:   http.StatusSeeOther,
		location: "/workshops/" + workshop.ID + "?" + url.Values{"email": {email}}.Encode(),
	}, nil
}

func releaseSeat(tx *Tx, r *http.Request) (response, error) {
	workshop, err := tx.workshop(r.PathValue("id"))
	if errors.Is(err, sql.ErrNoRows) {
		return problem(http.StatusNotFound, "Workshop not found.")
	}
	if err != nil {
		return response{}, err
	}
	if err := r.ParseForm(); err != nil {
		return render("workshop", workshop.Title, workshopPage{Workshop: workshop, EmailError: "The form could not be read. Enter your email again."}, http.StatusBadRequest)
	}
	email, err := normalizeEmail(r.PostForm.Get("email"))
	if err != nil {
		return render("workshop", workshop.Title, workshopPage{
			Workshop: workshop, Email: r.PostForm.Get("email"), EmailError: "Enter one valid email address without a display name.",
		}, http.StatusBadRequest)
	}
	reserved, err := tx.isReserved(workshop.ID, email)
	if err != nil {
		return response{}, err
	}
	if reserved {
		if err := tx.Emit(evt.SeatReleased{WorkshopID: workshop.ID, Email: email}); err != nil {
			return response{}, err
		}
	}
	return response{
		status:   http.StatusSeeOther,
		location: "/workshops/" + workshop.ID + "?" + url.Values{"email": {email}}.Encode(),
	}, nil
}
