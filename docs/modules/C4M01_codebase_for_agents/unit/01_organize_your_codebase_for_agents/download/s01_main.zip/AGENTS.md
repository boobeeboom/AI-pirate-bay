# Workshop Reservations

This is a workshop reservation app. 

This is a web app using HTMX + Unix + Go + SQLite + Event-driven Specs (HUGSES) with modular monolithic architecture and stack flattening.

## Progressive Disclosure

Always run `tree docs` at the beginning to get an overview of durable documents. Before changing documentation read `document_writing.md`.

Read `product.md` for the product vision, `behavior.md` for the accepted contract, and `piecemeal_growth.md` for the implementation mentality.

Business logic is tested via event-driven specs (BDD style) that map to features. To run specs: `make specs`. Read `specifications.md` when working on them. 

Do not touch tests or executable specs without explicit permission. Tests and specs are requirements, when proposing one, explain the behavior it would freeze and its coupling to implementation.

Do not treat questions as permission to make changes.

Use lowercase words separated by underscores in filenames and directories we control. Preserve conventional special filenames, structured dates, and tool-defined formats.

Environment uses `flake.nix`. If command isn't available in the shell and nix is present - access it via `nix develop -c $COMMAND`, e.g. `nix develop -c go version`, otherwise halt.