package main

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/spec"
	"bytes"
	"net/http"
	"os"
	"path/filepath"
	"slices"
	"strings"
	"testing"
)

var oneSeat = evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1}
var aliceReserved = evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"}

func TestRunnerReportsFailuresAndContinuesInOrder(t *testing.T) {
	var visited []string
	visit := func(name string) spec.Expectation {
		return spec.Custom(func(spec.Result) error {
			visited = append(visited, name)
			return nil
		})
	}
	suite := spec.Specs{
		spec.New("mismatched response", func(bld *spec.B) {
			bld.Given(oneSeat)
			bld.When(spec.Get("/workshops/october")).
				Then("all mismatches are reported").
				Covers("W1").
				Expect(visit("mismatch")).
				ExpectStatus(http.StatusCreated).
				ExpectEvents(aliceReserved).
				ExpectText("h1", "Wrong title")
		}),
		spec.New("panicking expectation", func(bld *spec.B) {
			bld.When(spec.Get("/")).
				Then("a panic fails its scenario").
				Covers("W1").
				Expect(visit("panic"), spec.Custom(func(spec.Result) error { panic("deliberate panic") }))
		}),
		spec.New("invalid setup", func(bld *spec.B) {
			bld.Given(oneSeat, oneSeat)
			bld.When(spec.Get("/")).
				Then("setup errors fail their scenario").
				Covers("W1").
				Expect(visit("must not run"))
		}),
		spec.New("independent next scenario", func(bld *spec.B) {
			bld.When(spec.Get("/workshops/october")).
				Then("later scenarios still run with fresh databases").
				Covers("W1").
				Expect(visit("next")).
				ExpectStatus(http.StatusNotFound)
		}),
	}
	var out bytes.Buffer
	if code := runContract(t, nil, &out, []spec.Feature{{Name: "runner", Specs: suite}}, "W1. Runner behavior."); code != 1 {
		t.Fatalf("failed suite returned %d, want 1", code)
	}
	if !slices.Equal(visited, []string{"mismatch", "panic", "next"}) {
		t.Fatalf("scenario execution order: %v", visited)
	}
	for _, fragment := range []string{
		"FAIL  W1 · runner / mismatched response", "Then all mismatches are reported",
		"Given evt.WorkshopCreated", "When GET /workshops/october",
		"want: 201 Created", "got: 200 OK", "want: evt.SeatReserved", "got: no events",
		`want: "Wrong title"`, `got: "Executable Specs"`,
		"scenario panicked: deliberate panic", "Given events:",
		"4 scenarios: 1 passed, 3 failed · 14 expectations",
	} {
		if !strings.Contains(out.String(), fragment) {
			t.Errorf("output missing %q:\n%s", fragment, out.String())
		}
	}
	if strings.Contains(out.String(), "PASS") {
		t.Errorf("runner printed passing scenarios:\n%s", out.String())
	}
}

func TestRunnerReturnsSuccessOnlyForExecutedExpectations(t *testing.T) {
	valid := spec.New("valid", func(bld *spec.B) {
		bld.When(spec.Get("/")).Then("the page is readable").Covers("W1")
	})
	secondRequest := valid
	secondRequest.WhenCount = 2
	missingRequest := spec.Spec{
		Requirements: []spec.RequirementID{"W1"},
		Name:         "missing request",
		Meaning:      "must run",
		Expectations: []spec.Expectation{spec.Events()},
	}
	missingExpectations := spec.New("missing expectations", func(bld *spec.B) {
		bld.When(spec.Post("/workshops", nil)).Then("must check something").Covers("W1")
	})
	for _, example := range []struct {
		name     string
		features []spec.Feature
		code     int
	}{
		{"passing suite", []spec.Feature{{Name: "runner", Specs: []spec.Spec{valid}}}, 0},
		{"empty suite", nil, 1},
		{"missing request", []spec.Feature{{Name: "runner", Specs: []spec.Spec{missingRequest}}}, 1},
		{"second request", []spec.Feature{{Name: "runner", Specs: []spec.Spec{secondRequest}}}, 1},
		{"missing expectations", []spec.Feature{{Name: "runner", Specs: []spec.Spec{missingExpectations}}}, 1},
	} {
		t.Run(example.name, func(t *testing.T) {
			var out bytes.Buffer
			if code := runContract(t, nil, &out, example.features, "W1. Runner behavior."); code != example.code {
				t.Fatalf("exit code: want %d, got %d\n%s", example.code, code, out.String())
			}
		})
	}
}

func runContract(t *testing.T, args []string, out *bytes.Buffer, features []spec.Feature, contract string) int {
	t.Helper()
	path := filepath.Join(t.TempDir(), "behavior.md")
	if err := os.WriteFile(path, []byte(contract), 0600); err != nil {
		t.Fatal(err)
	}
	return run(args, out, features, path)
}
