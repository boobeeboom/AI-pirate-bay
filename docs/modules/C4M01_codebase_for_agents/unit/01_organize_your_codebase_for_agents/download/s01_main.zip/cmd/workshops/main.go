package main

import (
	"ai_code_october_specs/app"
	"flag"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"time"
)

func main() {
	address := flag.String("addr", "127.0.0.1:8080", "HTTP listen address")
	database := flag.String("db", "var/workshops.sqlite", "SQLite file")
	flag.Parse()
	if err := os.MkdirAll(filepath.Dir(*database), 0755); err != nil {
		log.Fatal(err)
	}
	store, err := app.Open(*database)
	if err != nil {
		log.Fatal(err)
	}
	defer store.Close()
	server := &http.Server{
		Addr:              *address,
		Handler:           app.Handler(store),
		ReadHeaderTimeout: 5 * time.Second,
	}
	log.Printf("Workshops: http://%s (database: %s)", *address, *database)
	log.Fatal(server.ListenAndServe())
}
