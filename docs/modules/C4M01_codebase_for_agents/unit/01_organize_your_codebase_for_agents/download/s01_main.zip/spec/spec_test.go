package spec

import (
	"ai_code_october_specs/evt"
	"net/http"
	"reflect"
	"testing"
)

func TestSpecBuilder(t *testing.T) {
	given := evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1}
	emitted := evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"}
	subject := New("Reserve a seat", func(bld *B) {
		bld.Given(given)
		bld.When(Get("/workshops/october")).
			Then("the reservation is visible").
			Covers("W4", "W3").
			ExpectStatus(http.StatusConflict).
			ExpectEvents(emitted).
			ExpectEl("#reservation-status", With{"data-status": "reserved"})
	})

	if !reflect.DeepEqual(subject.Requirements, []RequirementID{"W4", "W3"}) || subject.Name != "Reserve a seat" {
		t.Fatalf("identity = %q / %q", subject.Requirements, subject.Name)
	}
	if !reflect.DeepEqual(subject.GivenEvents, []evt.Event{given}) {
		t.Fatalf("given = %#v", subject.GivenEvents)
	}
	if subject.Request.Method != http.MethodGet || subject.Request.URI != "/workshops/october" {
		t.Fatalf("request = %s %s", subject.Request.Method, subject.Request.URI)
	}
	if subject.Meaning != "the reservation is visible" {
		t.Fatalf("meaning = %q", subject.Meaning)
	}
	if subject.ExpectationCount() != 3 {
		t.Fatalf("expectations = %d, want 3", subject.ExpectationCount())
	}
	if subject.Expectations[0].kind != expectStatus || subject.Expectations[0].status != http.StatusConflict {
		t.Fatalf("status expectation = %#v", subject.Expectations[0])
	}
	if subject.Expectations[1].kind != expectEvents || !reflect.DeepEqual(subject.Expectations[1].events, []evt.Event{emitted}) {
		t.Fatalf("event expectation = %#v", subject.Expectations[1])
	}
}

func TestCoversRejectsInvalidLinks(t *testing.T) {
	for _, example := range []struct {
		name string
		link func(*StepBuilder)
	}{
		{"empty", func(step *StepBuilder) { step.Covers() }},
		{"combined string", func(step *StepBuilder) { step.Covers("W1, W12") }},
		{"malformed", func(step *StepBuilder) { step.Covers("W01") }},
		{"duplicate", func(step *StepBuilder) { step.Covers("W1", "W1") }},
		{"repeated declaration", func(step *StepBuilder) { step.Covers("W1").Covers("W2") }},
	} {
		t.Run(example.name, func(t *testing.T) {
			defer func() {
				if recover() == nil {
					t.Fatal("invalid requirement links were accepted")
				}
			}()
			New("Invalid links", func(bld *B) {
				example.link(bld.When(Get("/")).Then("requirements identify the promise"))
			})
		})
	}
}

func TestGetDefaultsToOKAndNoEvents(t *testing.T) {
	subject := New("Browse workshops", func(bld *B) {
		bld.When(Get("/")).Then("the catalogue is shown without recording events").Covers("W8")
	})

	if subject.ExpectationCount() != 2 {
		t.Fatalf("expectations = %d, want 2", subject.ExpectationCount())
	}
	if subject.Expectations[0].kind != expectStatus || subject.Expectations[0].status != http.StatusOK {
		t.Fatalf("status expectation = %#v", subject.Expectations[0])
	}
	if subject.Expectations[1].kind != expectEvents || len(subject.Expectations[1].events) != 0 {
		t.Fatalf("event expectation = %#v", subject.Expectations[1])
	}
}

func TestSpecsCollectSpecificationsInOrder(t *testing.T) {
	var subjects Specs
	subjects.Add("Create a workshop", func(bld *B) {
		bld.When(Post("/workshops", nil)).Then("the workshop is created").Covers("W1").ExpectNoEvents()
	})
	subjects.Add("Browse workshops", func(bld *B) {
		bld.When(Get("/")).Then("the catalogue is shown").Covers("W8")
	})

	if len(subjects) != 2 || subjects[0].Name != "Create a workshop" || subjects[1].Name != "Browse workshops" {
		t.Fatalf("subjects = %#v", subjects)
	}
}

func TestSpecRequiresExpectationDescription(t *testing.T) {
	defer func() {
		if recovered := recover(); recovered == nil {
			t.Fatal("New did not require an expectation description")
		}
	}()

	New("Create a workshop", func(bld *B) {
		bld.When(Post("/workshops", nil))
	})
}
