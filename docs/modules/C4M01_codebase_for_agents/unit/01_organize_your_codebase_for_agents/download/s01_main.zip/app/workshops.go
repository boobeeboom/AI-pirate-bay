package app

type Workshop struct {
	ID        string
	Title     string
	Capacity  int
	Remaining int
}

func (w Workshop) ReservedCount() int { return w.Capacity - w.Remaining }

func (tx *Tx) workshop(id string) (Workshop, error) {
	var workshop Workshop
	err := tx.QueryRow(`
SELECT id, title, capacity,
       capacity - (SELECT COUNT(*) FROM reservations WHERE workshop_id = workshops.id)
FROM workshops WHERE id = ?`, id).
		Scan(&workshop.ID, &workshop.Title, &workshop.Capacity, &workshop.Remaining)
	return workshop, err
}

func (tx *Tx) workshops() ([]Workshop, error) {
	rows, err := tx.Query(`
SELECT w.id, w.title, w.capacity, w.capacity - COUNT(r.email)
FROM workshops w LEFT JOIN reservations r ON r.workshop_id = w.id
GROUP BY w.id
ORDER BY w.rowid`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var workshops []Workshop
	for rows.Next() {
		var workshop Workshop
		if err := rows.Scan(&workshop.ID, &workshop.Title, &workshop.Capacity, &workshop.Remaining); err != nil {
			return nil, err
		}
		workshops = append(workshops, workshop)
	}
	return workshops, rows.Err()
}

func (tx *Tx) reservationEmails(id string) ([]string, error) {
	rows, err := tx.Query(`SELECT email FROM reservations WHERE workshop_id = ? ORDER BY email`, id)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var emails []string
	for rows.Next() {
		var email string
		if err := rows.Scan(&email); err != nil {
			return nil, err
		}
		emails = append(emails, email)
	}
	return emails, rows.Err()
}

func (tx *Tx) isReserved(id, email string) (bool, error) {
	var reserved bool
	err := tx.QueryRow(`SELECT EXISTS(SELECT 1 FROM reservations WHERE workshop_id = ? AND email = ?)`, id, email).Scan(&reserved)
	return reserved, err
}
