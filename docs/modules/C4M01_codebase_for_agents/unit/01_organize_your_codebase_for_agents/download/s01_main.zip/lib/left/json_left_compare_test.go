package left

import (
	"reflect"
	"testing"
)

func TestFlattenJSONValueNestedObjectsAndArrays(t *testing.T) {
	type line struct {
		Name   string `json:"name,omitempty"`
		Amount int    `json:"amount,omitempty"`
	}
	type invoice struct {
		Number string         `json:"number"`
		Lines  []line         `json:"lines,omitempty"`
		Meta   map[string]any `json:"meta,omitempty"`
	}

	got, err := FlattenJSONValue(invoice{
		Number: "SR-13",
		Lines: []line{
			{Name: "OpenAI Subscription", Amount: 20},
			{Name: "Claude Subscription", Amount: 20},
		},
		Meta: map[string]any{
			"customer-id": "cust-1",
		},
	})
	if err != nil {
		t.Fatalf("FlattenJSONValue() error = %v", err)
	}

	want := map[string]any{
		"number":              "SR-13",
		"lines[0].name":       "OpenAI Subscription",
		"lines[0].amount":     float64(20),
		"lines[1].name":       "Claude Subscription",
		"lines[1].amount":     float64(20),
		`meta["customer-id"]`: "cust-1",
	}

	if !reflect.DeepEqual(got, want) {
		t.Fatalf("FlattenJSONValue() mismatch\nwant: %#v\ngot:  %#v", want, got)
	}
}

func TestLeftMapDeltasNestedAndMissingValues(t *testing.T) {
	expected := map[string]any{
		"number":          "SR-13",
		"lines[0].amount": float64(20),
		"lines[1].name":   "Claude Subscription",
		"total":           float64(40),
	}
	actual := map[string]any{
		"number":          "SR-14",
		"lines[0].amount": float64(20),
	}

	got := LeftMapDeltas(expected, actual)
	want := []string{
		`lines[1].name: expected "Claude Subscription" got <unset>`,
		`number: expected "SR-13" got "SR-14"`,
		`total: expected 40 got <unset>`,
	}

	if !reflect.DeepEqual(got, want) {
		t.Fatalf("LeftMapDeltas() mismatch\nwant: %#v\ngot:  %#v", want, got)
	}
}

func TestFlattenJSONValueZeroBasicFieldsAreOmittedFromStructExpectations(t *testing.T) {
	type plain struct {
		Body    string  `json:"body"`
		Count   int     `json:"count"`
		Enabled bool    `json:"enabled"`
		Ratio   float64 `json:"ratio"`
	}
	type optional struct {
		Body    string  `json:"body,omitempty"`
		Count   int     `json:"count,omitempty"`
		Enabled bool    `json:"enabled,omitempty"`
		Ratio   float64 `json:"ratio,omitempty"`
	}

	expectedSpecified, err := FlattenJSONValue(plain{})
	if err != nil {
		t.Fatalf("FlattenJSONValue(plain{}) error = %v", err)
	}

	if len(expectedSpecified) != 0 {
		t.Fatalf("FlattenJSONValue(plain{}) unexpectedly included zero-value fields: %#v", expectedSpecified)
	}

	expectedOmitted, err := FlattenJSONValue(optional{})
	if err != nil {
		t.Fatalf("FlattenJSONValue(optional{}) error = %v", err)
	}
	if len(expectedOmitted) != 0 {
		t.Fatalf("FlattenJSONValue(optional{}) unexpectedly included zero-value fields: %#v", expectedOmitted)
	}
}

func TestFlattenJSONValueExplicitZeroMapValuesRemainSpecified(t *testing.T) {
	expected, err := FlattenJSONValue(map[string]any{
		"body":    "",
		"count":   0,
		"enabled": false,
		"ratio":   0.0,
	})
	if err != nil {
		t.Fatalf("FlattenJSONValue(map) error = %v", err)
	}

	actualMissing, err := FlattenJSONValue(map[string]any{})
	if err != nil {
		t.Fatalf("FlattenJSONValue(empty map) error = %v", err)
	}

	gotDeltas := LeftMapDeltas(expected, actualMissing)
	wantDeltas := []string{
		`body: expected "" got <unset>`,
		`count: expected 0 got <unset>`,
		`enabled: expected false got <unset>`,
		`ratio: expected 0 got <unset>`,
	}
	if !reflect.DeepEqual(gotDeltas, wantDeltas) {
		t.Fatalf("LeftMapDeltas() mismatch\nwant: %#v\ngot:  %#v", wantDeltas, gotDeltas)
	}
}

func TestFlattenJSONBytesRejectsNonObjectRoot(t *testing.T) {
	if _, err := FlattenJSONBytes([]byte(`["not","an","object"]`)); err == nil {
		t.Fatal("FlattenJSONBytes() expected error for non-object root")
	}
}
