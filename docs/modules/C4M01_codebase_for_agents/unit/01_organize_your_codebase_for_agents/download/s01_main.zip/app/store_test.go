package app

import (
	"ai_code_october_specs/evt"
	"database/sql"
	"errors"
	"net/http"
	"net/http/httptest"
	"net/url"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	"github.com/PuerkitoBio/goquery"
)

func openStore(t *testing.T, path string) *Store {
	t.Helper()
	store, err := Open(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = store.Close() })
	return store
}

func submit(handler http.Handler, path string, values url.Values) *httptest.ResponseRecorder {
	request := httptest.NewRequest(http.MethodPost, path, strings.NewReader(values.Encode()))
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, request)
	return response
}

func TestTransactionRollsBackJournalAndProjections(t *testing.T) {
	for _, failure := range []string{"after emission", "during projection"} {
		t.Run(failure, func(t *testing.T) {
			store := openStore(t, ":memory:")
			err := store.Transact(t.Context(), func(tx *Tx) error {
				if err := tx.Emit(evt.WorkshopCreated{WorkshopID: "one", Title: "Specs", Capacity: 1}); err != nil {
					return err
				}
				if failure == "during projection" {
					return tx.Emit(evt.SeatReserved{WorkshopID: "missing", Email: "alice@example.com"})
				}
				return errors.New("interrupted after emission")
			})
			if err == nil {
				t.Fatal("expected transaction failure")
			}
			history, err := store.History(t.Context())
			if err != nil || len(history) != 0 {
				t.Fatalf("rolled-back journal: %#v, %v", history, err)
			}
			err = store.Transact(t.Context(), func(tx *Tx) error {
				_, err := tx.workshop("one")
				return err
			})
			if !errors.Is(err, sql.ErrNoRows) {
				t.Fatalf("rolled-back workshop: %v", err)
			}
		})
	}
}

func TestHTTPJourneySurvivesRestartAndProjectionRebuild(t *testing.T) {
	path := filepath.Join(t.TempDir(), "workshops.sqlite")
	store := openStore(t, path)
	handler := Handler(store)
	created := submit(handler, "/workshops", url.Values{"title": {"Executable Specs"}, "capacity": {"1"}})
	if created.Code != http.StatusSeeOther {
		t.Fatalf("create: %d %s", created.Code, created.Body.String())
	}
	location := created.Header().Get("Location")
	reserved := submit(handler, location+"/reserve", url.Values{"email": {"alice@example.com"}})
	if reserved.Code != http.StatusSeeOther {
		t.Fatalf("reserve: %d %s", reserved.Code, reserved.Body.String())
	}
	before, err := store.History(t.Context())
	if err != nil || len(before) != 2 {
		t.Fatalf("committed history: %#v, %v", before, err)
	}
	// Projections are disposable. Reopening must reconstruct them from the
	// actual events emitted by the preceding HTTP requests.
	if _, err := store.db.Exec(`DELETE FROM reservations; DELETE FROM workshops;`); err != nil {
		t.Fatal(err)
	}
	if err := store.Close(); err != nil {
		t.Fatal(err)
	}
	reopened := openStore(t, path)
	if err := reopened.Rebuild(t.Context()); err != nil {
		t.Fatal(err)
	}
	after, err := reopened.History(t.Context())
	if err != nil || !reflect.DeepEqual(before, after) {
		t.Fatalf("replay changed history: %#v, %v", after, err)
	}

	for _, page := range []struct{ uri, selector, want string }{
		{reserved.Header().Get("Location"), `#reservation-status[data-status="reserved"]`, ""},
		{location, "#remaining", "0"},
		{location + "/reservations", "[data-reservation]", "alice@example.com"},
	} {
		response := httptest.NewRecorder()
		Handler(reopened).ServeHTTP(response, httptest.NewRequest(http.MethodGet, page.uri, nil))
		document, err := goquery.NewDocumentFromReader(response.Body)
		if err != nil || response.Code != http.StatusOK {
			t.Fatalf("read %s: status %d, %v", page.uri, response.Code, err)
		}
		element := document.Find(page.selector)
		if element.Length() != 1 {
			t.Errorf("%s %s: want one element, got %d", page.uri, page.selector, element.Length())
		}
		if got := element.Text(); page.want != "" && got != page.want {
			t.Errorf("%s %s: want %q, got %q", page.uri, page.selector, page.want, got)
		}
	}
}

func TestConcurrentRequestsCannotOverbookLastSeat(t *testing.T) {
	store := openStore(t, ":memory:")
	if err := store.Transact(t.Context(), func(tx *Tx) error {
		return tx.Emit(evt.WorkshopCreated{WorkshopID: "one", Title: "Specs", Capacity: 1})
	}); err != nil {
		t.Fatal(err)
	}
	handler := Handler(store)
	start := make(chan struct{})
	results := make(chan int, 2)
	for _, email := range []string{"alice@example.com", "bob@example.com"} {
		go func() {
			<-start
			results <- submit(handler, "/workshops/one/reserve", url.Values{"email": {email}}).Code
		}()
	}
	close(start)
	counts := map[int]int{}
	for range 2 {
		counts[<-results]++
	}
	if counts[http.StatusSeeOther] != 1 || counts[http.StatusConflict] != 1 {
		t.Fatalf("want one reservation and one full response, got %v", counts)
	}
	history, err := store.History(t.Context())
	if err != nil || len(history) != 2 {
		t.Fatalf("want creation and one reservation, got %#v, %v", history, err)
	}
	if _, ok := history[1].(evt.SeatReserved); !ok {
		t.Fatalf("expected reservation, got %T", history[1])
	}
	err = store.Transact(t.Context(), func(tx *Tx) error {
		workshop, err := tx.workshop("one")
		if err == nil && workshop.Remaining != 0 {
			t.Errorf("remaining seats: %d", workshop.Remaining)
		}
		return err
	})
	if err != nil {
		t.Fatal(err)
	}
}
