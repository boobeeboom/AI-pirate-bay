# Unit 3 walkthrough transcript

**Source:** Rinat Abdullin's Russian-language Unit 3 walkthrough (44:38), with participant questions. [Preserved transcript](../../01_capture/2026-10-29__unit_03_walkthrough_transcript.md). The transcript records its recording link, transcription method, provenance, and unresolved words; its stated capture date is 2026-10-28. The recording date is unverified.

**Topics:** AI Native Code, agent-assisted feature work, workshop capacity, behavior contracts, executable specifications, BDD, event-based scenarios, progressive disclosure, product hypotheses, project-specific helpers.

**Why open it:** A live example follows one feature from clarifying the capacity rule through a reviewed behavior contract, failing executable specs, implementation, and a manual run. The Q&A explains how the speaker distinguishes specs from unit tests and records temporary assumptions. This is a walkthrough of the speaker's approach, not independent evidence that it transfers to other projects.

**Useful passages:**

- [03:49–10:31](../../01_capture/2026-10-29__unit_03_walkthrough_transcript.md#L42-L85): Resolve the below-current-reservations rule, then plan documents, specs, and code in that order.
- [10:32–14:22](../../01_capture/2026-10-29__unit_03_walkthrough_transcript.md#L86-L115): Given/when/then scenarios use events to prepare state and reference behavior contract clauses.
- [14:23–26:19](../../01_capture/2026-10-29__unit_03_walkthrough_transcript.md#L116-L205): Review and shorten the contract; write specs before implementation and inspect their initial failures.
- [26:20–29:55](../../01_capture/2026-10-29__unit_03_walkthrough_transcript.md#L206-L239): Keep the documentation, spec, and code trees aligned as they grow; use outlines to navigate larger documents.
- [38:17–42:17](../../01_capture/2026-10-29__unit_03_walkthrough_transcript.md#L330-L397): Separate temporary role assumptions and product hypotheses from settled behavior; group specs for human use.
- [42:18–44:38](../../01_capture/2026-10-29__unit_03_walkthrough_transcript.md#L398-L436): Executable, externally observable specs versus code-internal unit tests.

**Related thread:** [Preserving behavior across feature changes](../arcs/preserving_behavior_across_feature_changes.md).
