package spec

import (
	"ai_code_october_specs/evt"
	"fmt"
	"net/http"
	"net/url"
	"regexp"
	"strings"
)

// Spec is declarative data. Runtime execution and application binding live in
// cmd/specs.
type Spec struct {
	Requirements []RequirementID
	Name         string
	GivenEvents  []evt.Event
	Request      Request
	WhenCount    int
	Meaning      string
	Expectations []Expectation
}

type Specs []Spec

type Feature struct {
	Name  string
	Specs []Spec
}

type Form map[string]string

type Request struct {
	Method string
	URI    string
	Form   url.Values
}

// B stands for builder.
type B struct {
	spec *Spec
}

type StepBuilder struct {
	spec *Spec
}

type RequirementID string

var requirementIDPattern = regexp.MustCompile(`^W[1-9][0-9]*$`)

func ParseRequirementID(value string) (RequirementID, error) {
	if !requirementIDPattern.MatchString(value) {
		return "", fmt.Errorf("invalid requirement ID %q", value)
	}
	return RequirementID(value), nil
}

func New(name string, configure func(*B)) Spec {
	requireDescription("spec name", name)
	if configure == nil {
		panic("spec configuration must not be nil")
	}

	subject := Spec{Name: name}
	configure(&B{spec: &subject})
	if subject.WhenCount > 0 {
		requireDescription("expectation description", subject.Meaning)
	}
	return subject
}

func (specs *Specs) Add(name string, configure func(*B)) {
	*specs = append(*specs, New(name, configure))
}

func (b *B) Given(events ...evt.Event) {
	b.spec.GivenEvents = append(b.spec.GivenEvents, events...)
}

func (b *B) When(request Request) *StepBuilder {
	b.spec.Request = request
	b.spec.WhenCount++
	if request.Method == http.MethodGet {
		b.spec.Expectations = append(
			b.spec.Expectations,
			Status(http.StatusOK),
			Events(),
		)
	}
	return &StepBuilder{spec: b.spec}
}

func (b *StepBuilder) Then(description string) *StepBuilder {
	requireDescription("expectation description", description)
	if b.spec.Meaning != "" {
		panic("expectation description is already set")
	}
	b.spec.Meaning = description
	return b
}

func (b *StepBuilder) Covers(requirements ...string) *StepBuilder {
	if len(b.spec.Requirements) != 0 {
		panic("scenario requirements are already set")
	}
	if len(requirements) == 0 {
		panic("Covers needs at least one requirement")
	}
	seen := make(map[RequirementID]bool, len(requirements))
	for _, value := range requirements {
		id, err := ParseRequirementID(value)
		if err != nil {
			panic(err)
		}
		if seen[id] {
			panic(fmt.Sprintf("duplicate requirement ID %q", id))
		}
		seen[id] = true
		b.spec.Requirements = append(b.spec.Requirements, id)
	}
	return b
}

func (b *StepBuilder) Expect(expectations ...Expectation) *StepBuilder {
	b.spec.Expectations = append(b.spec.Expectations, expectations...)
	return b
}

func (b *StepBuilder) ExpectStatus(statusCode int) *StepBuilder {
	b.removeExpectations(expectStatus, expectRedirect)
	return b.Expect(Status(statusCode))
}

func (b *StepBuilder) ExpectRedirect(uri string) *StepBuilder {
	b.removeExpectations(expectStatus, expectRedirect)
	return b.Expect(Redirect(uri))
}

func (b *StepBuilder) ExpectEvents(events ...evt.Event) *StepBuilder {
	b.removeExpectations(expectEvents)
	return b.Expect(Events(events...))
}

func (b *StepBuilder) ExpectNoEvents() *StepBuilder {
	return b.ExpectEvents()
}

func (b *StepBuilder) ExpectElementCount(selector string, count int) *StepBuilder {
	return b.Expect(Count(selector, count))
}

func (b *StepBuilder) ExpectNoElement(selector string) *StepBuilder {
	return b.ExpectElementCount(selector, 0)
}

func (b *StepBuilder) ExpectText(selector, text string) *StepBuilder {
	return b.Expect(Text(selector, text))
}

func (b *StepBuilder) ExpectEl(selector string, expected ...With) *StepBuilder {
	return b.Expect(El(selector, expected...))
}

func (b *StepBuilder) ExpectTexts(selector string, texts ...string) *StepBuilder {
	return b.Expect(Texts(selector, texts...))
}

func (b *StepBuilder) ExpectNoText(text string) *StepBuilder {
	return b.Expect(NoText(text))
}

func (b *StepBuilder) ExpectVisibleText(selector string, fragments ...string) *StepBuilder {
	return b.Expect(VisibleText(selector, fragments...))
}

func (b *StepBuilder) removeExpectations(kinds ...expectationKind) {
	filtered := b.spec.Expectations[:0]
	for _, expectation := range b.spec.Expectations {
		remove := false
		for _, kind := range kinds {
			if expectation.kind == kind {
				remove = true
				break
			}
		}
		if !remove {
			filtered = append(filtered, expectation)
		}
	}
	b.spec.Expectations = filtered
}

func (s Spec) ExpectationCount() int {
	return len(s.Expectations)
}

func Get(uri string) Request {
	return Request{Method: http.MethodGet, URI: uri}
}

func Post(uri string, fields Form) Request {
	values := url.Values{}
	for key, value := range fields {
		values.Set(key, value)
	}
	return Request{Method: http.MethodPost, URI: uri, Form: values}
}

func requireDescription(label, value string) {
	if strings.TrimSpace(value) == "" {
		panic(fmt.Sprintf("%s must not be empty", label))
	}
}
