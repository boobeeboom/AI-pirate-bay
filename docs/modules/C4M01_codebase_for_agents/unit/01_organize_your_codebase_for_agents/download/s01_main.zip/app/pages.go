package app

import (
	"bytes"
	"embed"
	"html/template"
)

//go:embed *.html style.css
var assets embed.FS

// Each page supplies its own content definition within the same layout.
var pages = func() map[string]*template.Template {
	result := make(map[string]*template.Template)
	for _, name := range []string{"home", "new_workshop", "workshop", "reservations"} {
		result[name] = template.Must(template.ParseFS(assets, "layout.html", name+".html"))
	}
	return result
}()

type layoutPage struct {
	Title       string
	Creating    bool
	Participant bool
	Content     any
}

type creationForm struct {
	Title         string
	Capacity      string
	TitleError    string
	CapacityError string
	FormError     string
}

type workshopPage struct {
	Workshop
	Email      string
	EmailError string
	Reserved   bool
}

type reservationsPage struct {
	Workshop
	Emails []string
}

func render(name, title string, content any, status int) (response, error) {
	var body bytes.Buffer
	err := pages[name].ExecuteTemplate(&body, "layout", layoutPage{Title: title, Creating: name == "new_workshop", Participant: name == "workshop", Content: content})
	return response{status: status, body: body.Bytes()}, err
}

func problem(status int, message string) (response, error) {
	return response{status: status, body: []byte(template.HTMLEscapeString(message))}, nil
}
