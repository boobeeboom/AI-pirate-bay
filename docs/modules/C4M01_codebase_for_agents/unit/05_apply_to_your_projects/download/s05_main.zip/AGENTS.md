# Technical Excellence Center

This control center helps us preserve engineering evidence, index useful sources, connect their stories, and deliberately apply practices across projects. `docs/` is its operating guidance; `00_inbox/` through `03_apply/` are its working memory.

Always run `python3 docs/tools/tree.py` at the start. Use `outline.py` to inspect large Markdown files, then read the relevant line ranges. Follow source references when the task needs evidence; do not load all incoming or captured material at startup.

Read `piecemeal_growth.md` before designing or changing the setup. Read `document_writing.md` before changing documentation. Keep filenames lowercase with underscores, preserving conventional names such as `AGENTS.md`.

Before ingesting material or updating working memory, read `working_memory.md`. Inbox entries wait for an explicit ingestion request. Ingestion does not authorize adopting a practice or changing a project.

For work in a registered project, read its entry under `03_apply/projects/`, then its current checkout's `AGENTS.md` and relevant local guidance. Checkout paths are relative to this control center's root. Product requirements and executable specifications remain authoritative in the project. Surface conflicts with shared guidance before changing those commitments.

Do not treat questions as permission to make changes. Do not add, remove, or modify tests or executable specifications without explicit permission for the kind being changed.
