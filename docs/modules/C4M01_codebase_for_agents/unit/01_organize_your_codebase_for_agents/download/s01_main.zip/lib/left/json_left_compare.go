package left

import (
	"encoding"
	"encoding/json"
	"fmt"
	"reflect"
	"sort"
	"strconv"
	"strings"
)

type emptyFlatContainer string

const (
	emptyFlatObject emptyFlatContainer = "{}"
	emptyFlatArray  emptyFlatContainer = "[]"
)

// FlattenJSONValue normalizes a JSON-serializable value and flattens it into dotted paths.
// Expected structs omit zero-valued fields; maps retain explicit zeros and nulls.
// Nested arrays use `[index]`; nested object keys use `.field` when identifier-safe and
// `["raw-key"]` otherwise.
func FlattenJSONValue(value any) (map[string]any, error) {
	normalized, err := normalizeExpectedJSONValue(reflect.ValueOf(value))
	if err != nil {
		return nil, err
	}
	if normalized == nil {
		normalized = map[string]any{}
	}

	body, err := json.Marshal(normalized)
	if err != nil {
		return nil, err
	}
	return FlattenJSONBytes(body)
}

// FlattenJSONBytes parses a JSON object and flattens it into dotted paths.
func FlattenJSONBytes(body []byte) (map[string]any, error) {
	var decoded any
	if err := json.Unmarshal(body, &decoded); err != nil {
		return nil, err
	}

	root, ok := decoded.(map[string]any)
	if !ok {
		return nil, fmt.Errorf("json root must be an object")
	}

	out := make(map[string]any)
	flattenFlatObject("", root, out)
	return out, nil
}

// LeftMapDeltas compares only keys populated on expected against actual.
// Extra keys on actual are ignored. Flatten both sides with these helpers first.
func LeftMapDeltas(expected, actual map[string]any) []string {
	if expected == nil {
		return nil
	}

	keys := make([]string, 0, len(expected))
	for key := range expected {
		keys = append(keys, key)
	}
	sort.Strings(keys)

	var deltas []string
	for _, key := range keys {
		expectedValue := expected[key]
		actualValue, ok := actual[key]
		if !ok {
			deltas = append(deltas, formatDelta(key, formatFlatValue(expectedValue), "<unset>"))
			continue
		}
		if !reflect.DeepEqual(expectedValue, actualValue) {
			deltas = append(deltas, formatDelta(
				key,
				formatFlatValue(expectedValue),
				formatFlatValue(actualValue),
			))
		}
	}

	return deltas
}

func flattenFlatObject(path string, obj map[string]any, out map[string]any) {
	if len(obj) == 0 {
		if path != "" {
			out[path] = emptyFlatObject
		}
		return
	}

	keys := make([]string, 0, len(obj))
	for key := range obj {
		keys = append(keys, key)
	}
	sort.Strings(keys)

	for _, key := range keys {
		flattenFlatValue(joinFlatPath(path, key), obj[key], out)
	}
}

func flattenFlatValue(path string, value any, out map[string]any) {
	switch typed := value.(type) {
	case map[string]any:
		flattenFlatObject(path, typed, out)
	case []any:
		if len(typed) == 0 {
			out[path] = emptyFlatArray
			return
		}
		for i, item := range typed {
			flattenFlatValue(fmt.Sprintf("%s[%d]", path, i), item, out)
		}
	default:
		out[path] = typed
	}
}

func joinFlatPath(path, key string) string {
	segment := formatFlatPathSegment(key)
	if path == "" {
		return segment
	}
	if segment != "" && segment[0] == '[' {
		return path + segment
	}
	return path + "." + segment
}

func formatFlatPathSegment(key string) string {
	if isIdentifier(key) {
		return key
	}
	return "[" + strconv.Quote(key) + "]"
}

func formatFlatValue(value any) string {
	switch typed := value.(type) {
	case emptyFlatContainer:
		return string(typed)
	default:
		body, err := json.Marshal(typed)
		if err != nil {
			return strconv.Quote(fmt.Sprintf("%v", typed))
		}
		return string(body)
	}
}

func normalizeExpectedJSONValue(value reflect.Value) (any, error) {
	for value.IsValid() && (value.Kind() == reflect.Interface || value.Kind() == reflect.Pointer) {
		if value.IsNil() {
			return nil, nil
		}
		value = value.Elem()
	}
	if !value.IsValid() {
		return nil, nil
	}

	if shouldRoundTripJSONValue(value) {
		return roundTripJSONValue(value.Interface())
	}

	switch value.Kind() {
	case reflect.Struct:
		return normalizeExpectedJSONObject(value)
	case reflect.Map:
		if value.IsNil() {
			return nil, nil
		}
		return normalizeExpectedJSONMap(value)
	case reflect.Slice, reflect.Array:
		return normalizeExpectedJSONArray(value)
	default:
		return value.Interface(), nil
	}
}

func normalizeExpectedJSONObject(value reflect.Value) (map[string]any, error) {
	out := make(map[string]any)
	typ := value.Type()
	for i := 0; i < typ.NumField(); i++ {
		field := typ.Field(i)
		if field.PkgPath != "" {
			continue
		}

		name, ok := jsonFieldName(field)
		if !ok {
			continue
		}

		fieldValue := value.Field(i)
		if fieldValue.IsZero() {
			continue
		}

		normalized, err := normalizeExpectedJSONValue(fieldValue)
		if err != nil {
			return nil, err
		}
		out[name] = normalized
	}
	return out, nil
}

func normalizeExpectedJSONMap(value reflect.Value) (map[string]any, error) {
	out := make(map[string]any, value.Len())
	for _, key := range value.MapKeys() {
		name, ok, err := jsonMapKeyString(key)
		if err != nil {
			return nil, err
		}
		if !ok {
			continue
		}
		normalized, err := normalizeExpectedJSONValue(value.MapIndex(key))
		if err != nil {
			return nil, err
		}
		out[name] = normalized
	}
	return out, nil
}

func normalizeExpectedJSONArray(value reflect.Value) ([]any, error) {
	out := make([]any, value.Len())
	for i := 0; i < value.Len(); i++ {
		normalized, err := normalizeExpectedJSONValue(value.Index(i))
		if err != nil {
			return nil, err
		}
		out[i] = normalized
	}
	return out, nil
}

func shouldRoundTripJSONValue(value reflect.Value) bool {
	jsonMarshalerType := reflect.TypeOf((*json.Marshaler)(nil)).Elem()
	textMarshalerType := reflect.TypeOf((*encoding.TextMarshaler)(nil)).Elem()

	typ := value.Type()
	if typ.Implements(jsonMarshalerType) || typ.Implements(textMarshalerType) {
		return true
	}
	return value.CanAddr() && (value.Addr().Type().Implements(jsonMarshalerType) || value.Addr().Type().Implements(textMarshalerType))
}

func roundTripJSONValue(value any) (any, error) {
	body, err := json.Marshal(value)
	if err != nil {
		return nil, err
	}
	var decoded any
	if err := json.Unmarshal(body, &decoded); err != nil {
		return nil, err
	}
	return decoded, nil
}

func jsonFieldName(field reflect.StructField) (string, bool) {
	tag := field.Tag.Get("json")
	if tag == "-" {
		return "", false
	}
	name, _, _ := strings.Cut(tag, ",")
	if name == "" {
		name = field.Name
	}
	return name, true
}

func jsonMapKeyString(value reflect.Value) (string, bool, error) {
	for value.IsValid() && (value.Kind() == reflect.Interface || value.Kind() == reflect.Pointer) {
		if value.IsNil() {
			return "", false, nil
		}
		value = value.Elem()
	}
	if !value.IsValid() {
		return "", false, nil
	}

	switch value.Kind() {
	case reflect.String:
		return value.String(), true, nil
	case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
		return strconv.FormatInt(value.Int(), 10), true, nil
	case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Uintptr:
		return strconv.FormatUint(value.Uint(), 10), true, nil
	}

	textMarshalerType := reflect.TypeOf((*encoding.TextMarshaler)(nil)).Elem()
	if value.Type().Implements(textMarshalerType) || (value.CanAddr() && value.Addr().Type().Implements(textMarshalerType)) {
		body, err := json.Marshal(value.Interface())
		if err != nil {
			return "", false, err
		}
		var decoded string
		if err := json.Unmarshal(body, &decoded); err != nil {
			return "", false, err
		}
		return decoded, true, nil
	}

	return "", false, fmt.Errorf("unsupported json map key type %s", value.Type())
}
