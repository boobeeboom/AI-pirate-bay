package evt

import (
	"encoding/json"
	"fmt"
)

// Event is closed to the durable event types defined in this package.
type Event interface {
	eventName() string
}

type WorkshopCreated struct {
	WorkshopID string `json:"workshop_id,omitempty"`
	Title      string `json:"title,omitempty"`
	Capacity   int    `json:"capacity,omitempty"`
}

func (WorkshopCreated) eventName() string { return "workshop_created" }

type SeatReserved struct {
	WorkshopID string `json:"workshop_id,omitempty"`
	Email      string `json:"email,omitempty"`
}

func (SeatReserved) eventName() string { return "seat_reserved" }

type SeatReleased struct {
	WorkshopID string `json:"workshop_id,omitempty"`
	Email      string `json:"email,omitempty"`
}

func (SeatReleased) eventName() string { return "seat_released" }

func Name(event Event) string { return event.eventName() }

func Decode(name string, payload []byte) (Event, error) {
	switch name {
	case "workshop_created":
		var event WorkshopCreated
		err := json.Unmarshal(payload, &event)
		return event, err
	case "seat_reserved":
		var event SeatReserved
		err := json.Unmarshal(payload, &event)
		return event, err
	case "seat_released":
		var event SeatReleased
		err := json.Unmarshal(payload, &event)
		return event, err
	default:
		return nil, fmt.Errorf("unknown event type %q", name)
	}
}
