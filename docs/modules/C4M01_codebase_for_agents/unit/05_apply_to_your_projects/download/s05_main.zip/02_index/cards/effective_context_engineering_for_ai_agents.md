# Effective context engineering for AI agents

**Source:** Anthropic, published 2025-09-29. [Original article](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents); [preserved inbox copy](../../01_capture/2026-10-30__effective_context_engineering_for_ai_agents.md), captured 2026-10-30. Original text and front matter are retained; the two diagram links point to local copies of the referenced images.

**Topics:** progressive disclosure, just-in-time context retrieval, agentic search, lightweight references, filesystem metadata, hybrid retrieval, attention budget, structured notes, compaction.

**Why open it:** Explains how an agent can discover context incrementally: retain paths and other identifiers, use names and metadata to choose where to look, and load relevant material as the task develops. Especially useful for the question of what a fresh agent needs up front versus what it can find later. The article describes Anthropic's approach and examples; it does not establish that a particular information hierarchy works across agent architectures.

**Useful passages:**

- [Context retrieval and agentic search](../../01_capture/2026-10-30__effective_context_engineering_for_ai_agents.md#context-retrieval-and-agentic-search): The central progressive disclosure passage connects lightweight references, metadata, and successive retrieval decisions. It also identifies exploration latency, navigation failures, and a hybrid of initial context with later search.
- [The anatomy of effective context](../../01_capture/2026-10-30__effective_context_engineering_for_ai_agents.md#the-anatomy-of-effective-context): Minimal context must still contain enough behavioral guidance; clear tool boundaries and selective outputs help agents navigate efficiently.
- [Compaction](../../01_capture/2026-10-30__effective_context_engineering_for_ai_agents.md#compaction) and [structured note-taking](../../01_capture/2026-10-30__effective_context_engineering_for_ai_agents.md#structured-note-taking): How selected context survives longer tasks, including the risk of losing details during summarization.

**Related thread:** [Progressive disclosure for agent context](../arcs/progressive_disclosure_for_agent_context.md).
