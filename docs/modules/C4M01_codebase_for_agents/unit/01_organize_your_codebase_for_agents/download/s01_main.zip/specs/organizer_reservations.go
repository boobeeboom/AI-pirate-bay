package specs

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/spec"
)

func organizerReservationSpecs() spec.Specs {
	var specs spec.Specs

	specs.Add("Organizer reads workshop occupancy", func(bld *spec.B) {
		bld.Given(
			evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 3},
			evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"},
			evt.SeatReserved{WorkshopID: "october", Email: "bob@example.com"},
		)
		bld.When(spec.Get("/workshops/october/reservations")).
			Then("the identified workshop shows its reserved, total, and remaining seats").
			Covers("W11").
			ExpectEl("#workshop-title", spec.With{"text": "Executable Specs"}).
			ExpectEl("#reserved", spec.With{"text": "2"}).
			ExpectEl("#capacity", spec.With{"text": "3"}).
			ExpectEl("#remaining", spec.With{"text": "1"})
	})

	specs.Add("Organizer views a workshop's reserved emails", func(bld *spec.B) {
		bld.Given(
			evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 3},
			evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"},
			evt.SeatReserved{WorkshopID: "october", Email: "bob@example.com"},
			evt.WorkshopCreated{WorkshopID: "november", Title: "Foundations", Capacity: 1},
			evt.SeatReserved{WorkshopID: "november", Email: "carol@example.com"},
		)
		bld.When(spec.Get("/workshops/october/reservations")).
			Then("the list contains exactly this workshop's reserved emails").
			Covers("W11").
			ExpectTexts("[data-reservation]", "alice@example.com", "bob@example.com")
	})

	specs.Add("Organizer views an empty reservations list", func(bld *spec.B) {
		bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1})
		bld.When(spec.Get("/workshops/october/reservations")).
			Then("the empty list is explained and shows zero reservations").
			Covers("W11").
			ExpectEl("#reserved", spec.With{"text": "0"}).
			ExpectElementCount("#empty-reservations", 1).
			ExpectNoElement("[data-reservation]")
	})

	return specs
}
