package specs

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/spec"
	"errors"
	"fmt"
	"net/http"
	"strings"
)

func workshopCreationSpecs() spec.Specs {
	var specs spec.Specs

	specs.Add("Visitor opens workshop creation", func(bld *spec.B) {
		bld.When(spec.Get("/workshops/new")).
			Then("creation has its own form and a way back to the catalogue").
			Covers("W1").
			ExpectEl("form:has(#title)", spec.With{"method": "post", "action": "/workshops"}).
			ExpectEl("form input#title", spec.With{"name": "title"}).
			ExpectEl("form:has(#title) input#capacity", spec.With{"name": "capacity"}).
			ExpectEl("#cancel-create", spec.With{"href": "/"})
	})

	specs.Add("Visitor corrects an invalid capacity", func(bld *spec.B) {
		bld.When(spec.Post("/workshops", spec.Form{"title": "  Event Storming  ", "capacity": "0"})).
			Then("the visitor can correct capacity without retyping the title").
			Covers("W1", "W12").
			ExpectStatus(http.StatusBadRequest).
			ExpectNoEvents().
			ExpectEl("#title", spec.With{"value": "  Event Storming  "}).
			ExpectEl("#capacity", spec.With{"value": "0"}).
			ExpectElementCount("#capacity-error", 1)
	})

	specs.Add("Visitor creates a workshop", func(bld *spec.B) {
		created := evt.WorkshopCreated{Title: "Executable Specs", Capacity: 2}
		bld.When(spec.Post("/workshops", spec.Form{"title": "  Executable Specs  ", "capacity": "2"})).
			Then("creation is recorded and the visitor receives its shareable destination").
			Covers("W1").
			ExpectEvents(created).
			Expect(createdWorkshopLink(created))
	})

	for _, example := range []struct {
		name   string
		fields spec.Form
	}{
		{"blank title", spec.Form{"title": " ", "capacity": "2"}},
		{"zero capacity", spec.Form{"title": "Specs", "capacity": "0"}},
		{"negative capacity", spec.Form{"title": "Specs", "capacity": "-1"}},
		{"fractional capacity", spec.Form{"title": "Specs", "capacity": "1.5"}},
		{"missing capacity", spec.Form{"title": "Specs"}},
	} {
		specs.Add("Visitor submits invalid workshop creation: "+example.name, func(bld *spec.B) {
			bld.When(spec.Post("/workshops", example.fields)).
				Then("invalid input creates no workshop").
				Covers("W1").
				ExpectStatus(http.StatusBadRequest).
				ExpectNoEvents()
		})
	}

	return specs
}

func createdWorkshopLink(expected evt.WorkshopCreated) spec.Expectation {
	return spec.Custom(func(result spec.Result) error {
		location := result.Header.Get("Location")
		id, ok := strings.CutPrefix(location, "/workshops/")
		if !ok || id == "" {
			return fmt.Errorf("creation needs a workshop destination with a nonempty ID; got %q", location)
		}
		created := expected
		created.WorkshopID = id
		return errors.Join(spec.Verify(
			[]spec.Expectation{spec.Redirect(location), spec.Events(created)},
			result,
		)...)
	})
}
