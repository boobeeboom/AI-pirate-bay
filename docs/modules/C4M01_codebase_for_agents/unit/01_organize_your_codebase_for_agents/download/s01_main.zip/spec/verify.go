package spec

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/lib/left"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"slices"
	"strings"

	"github.com/PuerkitoBio/goquery"
)

type Result struct {
	StatusCode int
	Header     http.Header
	Body       []byte
	Events     []evt.Event
}

type expectationKind uint8

const (
	expectStatus expectationKind = iota
	expectRedirect
	expectEvents
	expectCount
	expectText
	expectElement
	expectTexts
	expectNoText
	expectVisibleText
	expectCustom
)

// Expectation is structured evidence for a spec's promise.
type Expectation struct {
	kind       expectationKind
	status     int
	uri        string
	events     []evt.Event
	selector   string
	count      int
	text       string
	texts      []string
	fragments  []string
	properties With
	custom     func(Result) error
}

// With describes one element: "text" is normalized text, "text.exact" is raw
// text, and other keys name attributes. Unspecified properties are ignored.
type With map[string]string

func Status(want int) Expectation {
	return Expectation{kind: expectStatus, status: want}
}

func Redirect(want string) Expectation {
	return Expectation{kind: expectRedirect, uri: want}
}

// Events matches populated expected fields in order, allowing unrelated events.
// An empty expectation requires no new events.
func Events(want ...evt.Event) Expectation {
	return Expectation{kind: expectEvents, events: append([]evt.Event(nil), want...)}
}

func Count(selector string, want int) Expectation {
	return Expectation{kind: expectCount, selector: selector, count: want}
}

func Text(selector, want string) Expectation {
	return Expectation{kind: expectText, selector: selector, text: want}
}

func El(selector string, expected ...With) Expectation {
	if len(expected) > 1 {
		panic("element expectation accepts at most one property map")
	}
	if len(expected) == 1 && len(expected[0]) == 0 {
		panic("element expectation property map must not be empty")
	}
	var want With
	if len(expected) == 1 {
		want = make(With, len(expected[0]))
		for key, value := range expected[0] {
			if strings.TrimSpace(key) == "" {
				panic("HTML expectation key must not be empty")
			}
			want[key] = value
		}
	}
	return Expectation{kind: expectElement, selector: selector, properties: want}
}

func Texts(selector string, want ...string) Expectation {
	want = slices.Clone(want)
	slices.Sort(want)
	return Expectation{kind: expectTexts, selector: selector, texts: want}
}

func NoText(text string) Expectation {
	return Expectation{kind: expectNoText, text: text}
}

func VisibleText(selector string, fragments ...string) Expectation {
	if len(fragments) == 0 {
		panic("visible text expectation requires at least one fragment")
	}
	normalized := make([]string, len(fragments))
	for index, fragment := range fragments {
		normalized[index] = normalizeText(fragment)
		if normalized[index] == "" {
			panic("visible text fragment must not be empty")
		}
	}
	return Expectation{kind: expectVisibleText, selector: selector, fragments: normalized}
}

// Custom is the narrow extension seam for domain-specific relationships between
// otherwise structured observations.
func Custom(check func(Result) error) Expectation {
	if check == nil {
		panic("custom expectation must not be nil")
	}
	return Expectation{kind: expectCustom, custom: check}
}

func Verify(expectations []Expectation, result Result) []error {
	var document *goquery.Document
	needsDocument := false
	for _, expectation := range expectations {
		switch expectation.kind {
		case expectCount, expectText, expectElement, expectTexts, expectNoText, expectVisibleText:
			needsDocument = true
		}
	}
	if needsDocument {
		var err error
		document, err = goquery.NewDocumentFromReader(strings.NewReader(string(result.Body)))
		if err != nil {
			return []error{fmt.Errorf("read response HTML: %w", err)}
		}
	}

	var failures []error
	for _, expectation := range expectations {
		if err := verify(expectation, result, document); err != nil {
			failures = append(failures, err)
		}
	}
	return failures
}

func verify(expectation Expectation, result Result, document *goquery.Document) error {
	switch expectation.kind {
	case expectStatus:
		return verifyStatus(expectation.status, result)
	case expectRedirect:
		err := verifyStatus(http.StatusSeeOther, result)
		if got := result.Header.Get("Location"); got != expectation.uri {
			err = errors.Join(err, difference("redirect location", fmt.Sprintf("%q", expectation.uri), fmt.Sprintf("%q", got)))
		}
		return err
	case expectEvents:
		return verifyEvents(expectation.events, result.Events)
	case expectCount:
		return verifyCount(document, expectation.selector, expectation.count)
	case expectText:
		if err := verifyCount(document, expectation.selector, 1); err != nil {
			return err
		}
		if got := normalizeText(document.Find(expectation.selector).Text()); got != expectation.text {
			return difference("text: "+expectation.selector, fmt.Sprintf("%q", expectation.text), fmt.Sprintf("%q", got))
		}
		return nil
	case expectElement:
		return verifyElement(document, expectation.selector, expectation.properties)
	case expectTexts:
		var got []string
		document.Find(expectation.selector).Each(func(_ int, element *goquery.Selection) {
			got = append(got, normalizeText(element.Text()))
		})
		slices.Sort(got)
		if !slices.Equal(got, expectation.texts) {
			return difference("texts: "+expectation.selector, fmt.Sprintf("%q", expectation.texts), fmt.Sprintf("%q", got))
		}
		return nil
	case expectNoText:
		if strings.Contains(document.Text(), expectation.text) {
			return fmt.Errorf("page unexpectedly contains %q", expectation.text)
		}
		return nil
	case expectVisibleText:
		if err := verifyCount(document, expectation.selector, 1); err != nil {
			return err
		}
		actual := normalizeText(document.Find(expectation.selector).Text())
		var missing []string
		for _, fragment := range expectation.fragments {
			if !strings.Contains(actual, fragment) {
				missing = append(missing, fragment)
			}
		}
		if len(missing) > 0 {
			return fmt.Errorf(
				"visible text: %s\n  missing: %q\n      got: %q",
				expectation.selector,
				missing,
				actual,
			)
		}
		return nil
	case expectCustom:
		return expectation.custom(result)
	default:
		return fmt.Errorf("unknown expectation kind %d", expectation.kind)
	}
}

func verifyStatus(want int, result Result) error {
	if result.StatusCode != want {
		return difference("HTTP status", fmt.Sprintf("%d %s", want, http.StatusText(want)), fmt.Sprintf("%d %s", result.StatusCode, http.StatusText(result.StatusCode)))
	}
	return nil
}

func verifyEvents(want, got []evt.Event) error {
	if len(want) == 0 {
		if len(got) != 0 {
			return difference("recorded events", DescribeEvents(want), DescribeEvents(got))
		}
		return nil
	}
	actualIndex := 0
	for index, expected := range want {
		matched := false
		var mismatch error
		for actualIndex < len(got) {
			actual := got[actualIndex]
			actualIndex++
			if evt.Name(expected) != evt.Name(actual) {
				continue
			}
			if err := compareFields(fmt.Sprintf("event %d %T", index+1, expected), expected, actual); err != nil {
				if mismatch == nil {
					mismatch = err
				}
				continue
			}
			matched = true
			break
		}
		if !matched {
			if mismatch != nil {
				return mismatch
			}
			return difference(fmt.Sprintf("event %d was not found in order", index+1), DescribeEvents([]evt.Event{expected}), DescribeEvents(got))
		}
	}
	return nil
}

func verifyCount(document *goquery.Document, selector string, want int) error {
	if got := document.Find(selector).Length(); got != want {
		return difference("element count: "+selector, want, got)
	}
	return nil
}

func verifyElement(document *goquery.Document, selector string, want With) error {
	selection := document.Find(selector)
	if want == nil {
		if selection.Length() == 0 {
			return fmt.Errorf("HTML selector %q matched no elements", selector)
		}
		return nil
	}
	if err := verifyCount(document, selector, 1); err != nil {
		return err
	}
	actual := With{}
	for _, attribute := range selection.Get(0).Attr {
		actual[attribute.Key] = attribute.Val
	}
	actual["text"] = normalizeText(selection.Text())
	actual["text.exact"] = selection.Text()
	return compareFields(fmt.Sprintf("HTML selector %q", selector), want, actual)
}

func difference(subject string, want, got any) error {
	return fmt.Errorf("%s\n  want: %v\n   got: %v", subject, want, got)
}

func compareFields(subject string, want, got any) error {
	expected, err := left.FlattenJSONValue(want)
	if err != nil {
		return fmt.Errorf("%s: prepare expected fields: %w", subject, err)
	}
	actual, err := left.FlattenJSONBytes([]byte(jsonText(got)))
	if err != nil {
		return fmt.Errorf("%s: read actual fields: %w", subject, err)
	}
	if deltas := left.LeftMapDeltas(expected, actual); len(deltas) > 0 {
		return fmt.Errorf("%s:\n%s", subject, strings.Join(deltas, "\n"))
	}
	return nil
}

func jsonText(value any) string {
	payload, err := json.Marshal(value)
	if err != nil {
		panic(err)
	}
	return string(payload)
}

func DescribeEvents(events []evt.Event) string {
	if len(events) == 0 {
		return "no events"
	}
	descriptions := make([]string, 0, len(events))
	for _, event := range events {
		descriptions = append(descriptions, fmt.Sprintf("%T %s", event, jsonText(event)))
	}
	return strings.Join(descriptions, "; ")
}

func normalizeText(value string) string {
	return strings.Join(strings.Fields(value), " ")
}
