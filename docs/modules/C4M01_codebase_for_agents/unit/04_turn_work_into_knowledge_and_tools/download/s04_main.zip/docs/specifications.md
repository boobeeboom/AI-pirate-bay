# Specification boundary

Executable scenarios interpret the accepted requirements in `behavior.md`. `Covers("W4", "W3")` links a scenario to the requirements it directly interprets, with its primary requirement first. The `Then` text states the promise, and expectations supply its executable evidence. Review changes to the intended behavior before changing its executable interpretations.

## Running specifications

`make specs` runs the standalone command in `cmd/specs`. The `spec` package owns the declarative model and response verification, `specs` owns a catalogue of focused workshop features, and `cmd/specs` owns application execution. Scenarios are ordinary `spec.Spec` values built with `New`, `Given`, `When`, `Then`, and `Expect*`; they do not use `testing.T` or test discovery. The runner executes them sequentially in catalogue and declaration order, prints only failures, and ends with scenario and expectation totals. Failures include the input and expected-versus-actual differences. Failed or panicking scenarios do not prevent later scenarios from running; any failure gives the process a nonzero exit status.

## Requirement links and coverage

Every run validates requirement links against the numbered W clauses in `behavior.md` before executing scenarios. Missing, unknown, or duplicate links and duplicate document IDs fail with exit code 2; scenario failures exit 1. `go run ./cmd/specs -coverage` adds a flat requirement → scenario → outcome report after the complete run, including after failures. Rows follow document and scenario declaration order. `NONE` means no scenario links to that requirement; `PASS` and `FAIL` describe the linked interpretations, not the completeness of the requirement's evidence. Unlinked requirements remain visible without failing the run. The report covers the standalone scenarios; storage tests remain supporting evidence.

## Writing scenarios

Each business scenario has one HTTP request and a fresh SQLite database that is closed after the scenario. `Given` events are committed through the application's event application path. `When` sends an HTTP request through the router and handler. Expectations check the response and newly committed journal entries.

```go
spec.New("Participant reserves the last available seat", func(bld *spec.B) {
    bld.Given(oneSeat)
    bld.When(spec.Post("/workshops/october/reserve", spec.Form{"email": " Alice@Example.COM "})).
        Then("the reservation is recorded with the normalized email").
        Covers("W4", "W3").
        ExpectRedirect("/workshops/october?email=alice%40example.com").
        ExpectEvents(aliceReserved)
})
```

Give each independently meaningful behavior one owning scenario, named for its actor context and action. Keep evidence for the same outcome together; separate outcomes such as occupancy, reservation lists, and navigation. Organize files and catalogue entries by that ownership. For a command, assert events and its HTTP outcome. For a page, seed only the relevant history and assert what the visitor can see or submit. Keep only evidence needed to establish the promise. Multi-request storage checks verify that commands, restart/replay, and subsequent pages work together.

## Development process

Adopt the TDD mindset: change feature scenarios first, implement code next.

## Deliberate coupling

- The event names and their meaningful fields are a durable domain contract.
- Nonempty event expectations match an ordered subsequence of the recorded events. Additional events are ignored, including events of the same type whose fields do not match. Each expected occurrence consumes a separate actual event. Within each event, only populated expected JSON fields are compared, allowing generated IDs and additional fields. Zero-valued omitted fields are not assertions. An empty expectation still requires no new events.
- HTML checks use behavior-bearing IDs, form actions, input names, and a small set of data attributes. They preserve meaningful values and status rather than freezing CSS, element nesting, or incidental copy.
- `El(selector, With{...})` checks the supplied properties of exactly one element, ignoring other properties. `text` means normalized text and `text.exact` means raw text; other keys name attributes. Explicit empty attribute values must be present and empty. `El(selector)` without properties checks that at least one element exists.
- Use selectors to identify elements and property maps to describe their promised values, so failures report the mismatched attribute or text. `ExpectNoElement` expresses absence; retain element counts where cardinality is part of the existing promise.
- Object/map comparisons use coding2's `lib/left` helpers: expected struct zero values are omitted, explicit map values (including zero, empty, and null) are checked, and additional actual fields are ignored. Differences identify the mismatched field paths.
- Every scenario checks that the existing journal prefix remains unchanged.
- `Events()` explicitly asserts that no new events were recorded. An empty suite or a scenario missing its request or expectations fails instead of reporting a vacuous pass.

## Supporting evidence

Storage tests exercise failed event batches, discarded projections, repeated replay, restart, an HTTP create/reserve/read journey, and competing requests for the last seat. They establish the persistence and transaction guarantees on which the product scenarios depend. These infrastructure checks remain Go unit tests, as do the runner, matchers, and workshop-creation assertion that relates the generated event identity to its redirect. `make check` runs the standalone specs and unit tests with the race detector, followed by vet and the application build.

Human review determines which behavior should be promised. Passing checks does not establish that the requirements are complete.
