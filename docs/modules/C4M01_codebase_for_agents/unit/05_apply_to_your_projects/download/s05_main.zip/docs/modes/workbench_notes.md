Write from the workbench, not the process office.

Use short, concrete, first-person notes. Capture what I want, what I tried, what happened, what comes next, and what is still unclear. Keep exact names, paths, commands, constraints, and numbers.

Cut process language and sections added only to make the note look complete. Stop when the note is enough to resume the work.
