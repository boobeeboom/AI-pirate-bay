package app

import (
	"ai_code_october_specs/evt"
	"context"
	"database/sql"
	"encoding/json"
	"fmt"

	_ "modernc.org/sqlite"
)

type Store struct {
	db *sql.DB
}

type Tx struct {
	*sql.Tx
}

const projectionSchema = `
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS workshops;
CREATE TABLE workshops (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    capacity INTEGER NOT NULL CHECK (capacity > 0)
);
CREATE TABLE reservations (
    workshop_id TEXT NOT NULL REFERENCES workshops(id),
    email TEXT NOT NULL,
    PRIMARY KEY (workshop_id, email)
);`

func Open(path string) (*Store, error) {
	db, err := sql.Open("sqlite", path)
	if err != nil {
		return nil, err
	}
	// One service process, one connection: the read/decide/append transaction
	// serializes reservations, including competing requests for the last seat.
	db.SetMaxOpenConns(1)
	db.SetMaxIdleConns(1)
	s := &Store{db: db}
	_, err = db.Exec(`PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS _events (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    payload TEXT NOT NULL
);`)
	if err == nil {
		err = s.Rebuild(context.Background())
	}
	if err != nil {
		_ = db.Close()
		return nil, fmt.Errorf("open workshop store: %w", err)
	}
	return s, nil
}

func (s *Store) Close() error { return s.db.Close() }

func (s *Store) Transact(ctx context.Context, work func(*Tx) error) error {
	tx, err := s.db.BeginTx(ctx, nil)
	if err != nil {
		return err
	}
	defer tx.Rollback()
	if err := work(&Tx{tx}); err != nil {
		return err
	}
	return tx.Commit()
}

func (tx *Tx) Emit(events ...evt.Event) error {
	for _, event := range events {
		payload, err := json.Marshal(event)
		if err != nil {
			return err
		}
		if _, err := tx.Exec(`INSERT INTO _events (name, payload) VALUES (?, ?)`, evt.Name(event), string(payload)); err != nil {
			return err
		}
		if err := tx.apply(event); err != nil {
			return err
		}
	}
	return nil
}

func (tx *Tx) history() ([]evt.Event, error) {
	rows, err := tx.Query(`SELECT name, payload FROM _events ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	var events []evt.Event
	for rows.Next() {
		var name string
		var payload []byte
		if err := rows.Scan(&name, &payload); err != nil {
			return nil, err
		}
		event, err := evt.Decode(name, payload)
		if err != nil {
			return nil, err
		}
		events = append(events, event)
	}
	return events, rows.Err()
}

func (s *Store) History(ctx context.Context) (events []evt.Event, err error) {
	err = s.Transact(ctx, func(tx *Tx) error {
		events, err = tx.history()
		return err
	})
	return
}

// Rebuild replaces projections atomically without changing the journal.
func (s *Store) Rebuild(ctx context.Context) error {
	return s.Transact(ctx, func(tx *Tx) error {
		events, err := tx.history()
		if err != nil {
			return err
		}
		if _, err := tx.Exec(projectionSchema); err != nil {
			return err
		}
		for _, event := range events {
			if err := tx.apply(event); err != nil {
				return err
			}
		}
		return nil
	})
}
