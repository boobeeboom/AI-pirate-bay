package specs

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/spec"
	"net/http"
	"testing"
)

func TestCreatedWorkshopLinkFollowsTheMatchingEvent(t *testing.T) {
	created := evt.WorkshopCreated{WorkshopID: "generated", Title: "Executable Specs", Capacity: 2}
	unrelated := evt.WorkshopCreated{WorkshopID: "other", Title: "Other workshop", Capacity: 1}
	missingID := created
	missingID.WorkshopID = ""
	for _, example := range []struct {
		name     string
		events   []evt.Event
		location string
		pass     bool
	}{
		{"unrelated events surround creation", []evt.Event{unrelated, created, (evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"})}, "/workshops/generated", true},
		{"additional matching events are allowed", []evt.Event{created, created}, "/workshops/generated", true},
		{"redirect cannot follow unrelated creation", []evt.Event{unrelated, created}, "/workshops/other", false},
		{"creation is required", []evt.Event{(evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"})}, "/workshops/generated", false},
		{"identity is required", []evt.Event{missingID}, "/workshops/", false},
	} {
		t.Run(example.name, func(t *testing.T) {
			failures := spec.Verify([]spec.Expectation{createdWorkshopLink(evt.WorkshopCreated{Title: created.Title, Capacity: created.Capacity})}, spec.Result{
				StatusCode: http.StatusSeeOther,
				Header:     http.Header{"Location": {example.location}},
				Events:     example.events,
			})
			if (len(failures) == 0) != example.pass {
				t.Fatalf("want pass=%v, got %v", example.pass, failures)
			}
		})
	}
}
