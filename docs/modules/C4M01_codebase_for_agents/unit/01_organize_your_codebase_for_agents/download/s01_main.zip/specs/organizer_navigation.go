package specs

import (
	"ai_code_october_specs/evt"
	"ai_code_october_specs/spec"
)

func organizerNavigationSpecs() spec.Specs {
	var specs spec.Specs

	for _, page := range []struct{ name, uri, active string }{
		{"catalogue", "/", "/"},
		{"creation", "/workshops/new", "/workshops/new"},
		{"reservations", "/workshops/october/reservations", "/"},
	} {
		specs.Add("Organizer navigates from the "+page.name+" page", func(bld *spec.B) {
			bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1})
			bld.When(spec.Get(page.uri)).
				Then("the product, catalogue, and creation are reachable from the top bar").
				Covers("W10").
				ExpectEl("#product-link", spec.With{"href": "/", "text": "Workshop Reservations"}).
				ExpectElementCount(`#primary-nav a[href="/"]`, 1).
				ExpectElementCount(`#primary-nav a[href="/workshops/new"]`, 1)
		})
		specs.Add("Organizer locates the "+page.name+" page in navigation", func(bld *spec.B) {
			bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1})
			bld.When(spec.Get(page.uri)).
				Then("the current navigation section is identified").
				Covers("W10").
				ExpectEl("#primary-nav a.active", spec.With{"href": page.active})
		})
		specs.Add("Organizer follows the "+page.name+" breadcrumb", func(bld *spec.B) {
			bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1})
			step := bld.When(spec.Get(page.uri)).
				Covers("W10")
			if page.uri == "/" {
				step.Then("the catalogue has no breadcrumb back to itself").
					ExpectNoElement(`#breadcrumbs a[href="/"]`)
			} else {
				step.Then("the breadcrumb returns to the workshop catalogue").
					ExpectElementCount(`#breadcrumbs a[href="/"]`, 1)
			}
		})
	}

	for _, example := range []struct {
		name   string
		events []evt.Event
	}{
		{"empty", nil},
		{"populated", []evt.Event{(evt.SeatReserved{WorkshopID: "october", Email: "alice@example.com"})}},
	} {
		specs.Add("Organizer opens the participant link from the "+example.name+" reservations page", func(bld *spec.B) {
			bld.Given(evt.WorkshopCreated{WorkshopID: "october", Title: "Executable Specs", Capacity: 1})
			bld.Given(example.events...)
			bld.When(spec.Get("/workshops/october/reservations")).
				Then("sharing and the breadcrumb lead to the workshop without an email or a separate workshop navigation bar").
				Covers("W2", "W10").
				ExpectEl("#share-link", spec.With{"href": "/workshops/october"}).
				ExpectEl(`#breadcrumbs a:not([href="/"])`, spec.With{"href": "/workshops/october"}).
				ExpectNoElement("#workshop-nav")
		})
	}

	return specs
}
