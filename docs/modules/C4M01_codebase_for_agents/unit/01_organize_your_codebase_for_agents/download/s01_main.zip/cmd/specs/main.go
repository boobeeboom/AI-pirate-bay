package main

import (
	"ai_code_october_specs/app"
	"ai_code_october_specs/spec"
	"ai_code_october_specs/specs"
	"context"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"net/http/httptest"
	"os"
	"reflect"
	"strings"
)

func main() {
	os.Exit(run(os.Args[1:], os.Stdout, specs.Features, "docs/behavior.md"))
}

func run(args []string, out io.Writer, features []spec.Feature, contractPath string) int {
	flags := flag.NewFlagSet("specs", flag.ContinueOnError)
	flags.SetOutput(out)
	coverage := flags.Bool("coverage", false, "report requirements, linked scenarios, and their outcomes after the full run")
	if err := flags.Parse(args); err != nil {
		if errors.Is(err, flag.ErrHelp) {
			return 0
		}
		return 2
	}
	if flags.NArg() != 0 {
		fmt.Fprintf(out, "specs: unexpected arguments: %s\n", strings.Join(flags.Args(), " "))
		return 2
	}
	total := 0
	for _, feature := range features {
		total += len(feature.Specs)
	}
	if total == 0 {
		fmt.Fprintln(out, "FAIL  No scenarios to run.")
		return 1
	}
	contract, err := os.Open(contractPath)
	if err != nil {
		fmt.Fprintf(out, "specs: requirements: %v\n", err)
		return 2
	}
	requirements, err := readRequirements(contract)
	_ = contract.Close()
	if err == nil {
		err = validateRequirements(requirements, features)
	}
	if err != nil {
		fmt.Fprintf(out, "specs: %s: %v\n", contractPath, err)
		return 2
	}
	failed := 0
	expectations := 0
	var outcomes []scenarioOutcome
	for _, feature := range features {
		for _, scenario := range feature.Specs {
			expectations += scenario.ExpectationCount()
			failures := execute(scenario)
			outcomes = append(outcomes, scenarioOutcome{Feature: feature.Name, Scenario: scenario, Failures: failures})
			if len(failures) == 0 {
				continue
			}
			failed++
			fmt.Fprintf(out, "FAIL  %s · %s / %s\n", describeRequirements(scenario.Requirements), feature.Name, scenario.Name)
			fmt.Fprintf(out, "      Then %s\n", scenario.Meaning)
			fmt.Fprintf(out, "      Given %s\n", spec.DescribeEvents(scenario.GivenEvents))
			fmt.Fprintf(out, "      When %s %s\n", scenario.Request.Method, scenario.Request.URI)
			if scenario.Request.Form != nil {
				fmt.Fprintf(out, "      Form %s\n", jsonText(scenario.Request.Form))
			}
			for _, err := range failures {
				fmt.Fprintf(out, "      %s\n", strings.ReplaceAll(err.Error(), "\n", "\n      "))
			}
			fmt.Fprintln(out)
		}
	}
	fmt.Fprintf(out, "%d scenarios: %d passed, %d failed · %d expectations\n", total, total-failed, failed, expectations)
	if *coverage {
		printCoverage(out, requirements, outcomes)
	}
	if failed > 0 {
		return 1
	}
	return 0
}

func execute(scenario spec.Spec) (failures []error) {
	defer func() {
		if value := recover(); value != nil {
			failures = append(failures, fmt.Errorf("scenario panicked: %v", value))
		}
	}()
	if scenario.WhenCount != 1 || scenario.Request.Method == "" || scenario.Request.URI == "" {
		return []error{fmt.Errorf("a scenario needs exactly one When request")}
	}
	if scenario.Meaning == "" || len(scenario.Expectations) == 0 {
		return []error{fmt.Errorf("a scenario needs a Then promise and at least one expectation")}
	}
	store, err := app.Open(":memory:")
	if err != nil {
		return []error{fmt.Errorf("open scenario database: %w", err)}
	}
	defer func() {
		if err := store.Close(); err != nil {
			failures = append(failures, fmt.Errorf("close scenario database: %w", err))
		}
	}()
	ctx := context.Background()
	if err := store.Transact(ctx, func(tx *app.Tx) error { return tx.Emit(scenario.GivenEvents...) }); err != nil {
		return []error{fmt.Errorf("Given events: %w", err)}
	}
	before, err := store.History(ctx)
	if err != nil {
		return []error{fmt.Errorf("read history before request: %w", err)}
	}
	req := httptest.NewRequest(scenario.Request.Method, scenario.Request.URI, strings.NewReader(scenario.Request.Form.Encode()))
	if scenario.Request.Form != nil {
		req.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	}
	response := httptest.NewRecorder()
	app.Handler(store).ServeHTTP(response, req)
	after, err := store.History(ctx)
	if err != nil {
		return []error{fmt.Errorf("read history after request: %w", err)}
	}
	if len(after) < len(before) {
		return []error{fmt.Errorf("request removed existing event history")}
	}
	for index, event := range before {
		if !reflect.DeepEqual(event, after[index]) {
			return []error{fmt.Errorf("request changed historical event %d", index+1)}
		}
	}
	return spec.Verify(scenario.Expectations, spec.Result{
		StatusCode: response.Code,
		Header:     response.Header(),
		Body:       response.Body.Bytes(),
		Events:     after[len(before):],
	})
}

func jsonText(value any) string {
	payload, err := json.Marshal(value)
	if err != nil {
		panic(err)
	}
	return string(payload)
}
